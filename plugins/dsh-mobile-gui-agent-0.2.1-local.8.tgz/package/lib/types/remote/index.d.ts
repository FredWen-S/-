/** Typert Remote adapter for the Phone GUI; business behavior remains in `ctx.phoneRuns`. */
import { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import '../core/index.ts';
import type { PhoneDeviceId, PhoneDeviceInfo, PhoneRunView, StartPhoneRunRequest } from '../core/index.ts';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { PhoneScreenshotResponse } from './types.ts';
export type { PhoneScreenshotResponse } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        phoneAgent: PhoneAgentRemote;
    }
}
/** Host Remote namespace that delegates every call to the abstract Phone run service. */
export declare class PhoneAgentRemote extends TypertRemoteService {
    /** Agent lookup and Phone run service dependencies. */
    static inject: string[];
    /** Register the `phoneAgent` Remote namespace. */
    constructor(ctx: Context);
    /**
     * List current provider devices.
     * @returns Device records including unusable states.
     */
    listDevices(): Promise<readonly PhoneDeviceInfo[]>;
    /**
     * Connect one wireless ADB endpoint.
     * @param address - Host and port.
     * @returns Connected device record.
     */
    connect(address: string): Promise<PhoneDeviceInfo>;
    /**
     * Return the exact Agent's current Phone run.
     * @param agent - Typert-resolved live Agent.
     * @returns Run view or undefined before start.
     */
    getView(agent: Agent): PhoneRunView | undefined;
    /**
     * Capture a screenshot for the active run or selected idle device.
     * @param agent - Typert-resolved live Agent.
     * @param deviceId - Optional selected device before start.
     * @returns Bounded base64 PNG and intrinsic metadata.
     */
    getScreenshot(agent: Agent, deviceId?: PhoneDeviceId): Promise<PhoneScreenshotResponse>;
    /**
     * Start one Phone run.
     * @param agent - Typert-resolved live Agent.
     * @param request - Concrete device and task.
     * @returns Initial run view.
     */
    start(agent: Agent, request: StartPhoneRunRequest): Promise<PhoneRunView>;
    /**
     * Pause one Phone run.
     * @param agent - Typert-resolved live Agent.
     * @returns Paused run view.
     */
    pause(agent: Agent): Promise<PhoneRunView>;
    /**
     * Resume one Phone run.
     * @param agent - Typert-resolved live Agent.
     * @returns Running run view.
     */
    resume(agent: Agent): Promise<PhoneRunView>;
    /**
     * Stop one Phone run.
     * @param agent - Typert-resolved live Agent.
     * @returns Stopped run view after quiescence.
     */
    stop(agent: Agent): Promise<PhoneRunView>;
}
export default PhoneAgentRemote;
//# sourceMappingURL=index.d.ts.map