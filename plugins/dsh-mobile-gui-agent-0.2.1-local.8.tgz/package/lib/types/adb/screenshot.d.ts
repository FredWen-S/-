/** PNG validation and comparison signatures. */
import type { PhoneScreenshot } from '../core/index.ts';
/**
 * Validate PNG bytes and compute exact and low-resolution signatures.
 * @param data - Bounded `screencap -p` stdout.
 * @param timestamp - Capture time.
 * @returns Intrinsic screenshot metadata and comparison signature.
 */
export declare function decodeScreenshot(data: Uint8Array, timestamp: number): Promise<PhoneScreenshot>;
/**
 * Compute normalized mean absolute pixel difference between comparison signatures.
 * @param before - Base64 grayscale thumbnail.
 * @param after - Base64 grayscale thumbnail.
 * @returns Difference from zero to one, or one for incompatible signatures.
 */
export declare function screenshotDifference(before: string, after: string): number;
//# sourceMappingURL=screenshot.d.ts.map