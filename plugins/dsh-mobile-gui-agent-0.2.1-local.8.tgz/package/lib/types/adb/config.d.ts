/** ADB provider configuration and explicit default resolution. */
import type { Config } from './index.ts';
/** Complete validated ADB provider configuration. */
export interface ResolvedConfig {
    /** Resolved executable setting. */
    readonly adbPath: string;
    /** User-reviewed helper APK eligible for an approved install. */
    readonly unicodeImeApkPath?: string;
    /** Resolved command timeout. */
    readonly commandTimeoutMs: number;
    /** Resolved process grace. */
    readonly processGraceMs: number;
    /** Resolved screenshot byte cap. */
    readonly screenshotMaxBytes: number;
    /** Resolved hierarchy byte cap. */
    readonly hierarchyMaxBytes: number;
    /** Resolved diagnostic byte cap. */
    readonly diagnosticMaxBytes: number;
    /** Resolved hierarchy count cap. */
    readonly hierarchyMaxElements: number;
    /** Resolved hierarchy serialization cap. */
    readonly hierarchyMaxSerializedBytes: number;
    /** Resolved UIAutomator attempt count. */
    readonly hierarchyAttempts: number;
    /** Resolved delay between UIAutomator attempts. */
    readonly hierarchyRetryDelayMs: number;
    /** Resolved stable-screen poll interval. */
    readonly stablePollMs: number;
    /** Resolved stable comparison count. */
    readonly stableSamples: number;
    /** Resolved stable-screen timeout. */
    readonly stableTimeoutMs: number;
    /** Resolved normalized stable threshold. */
    readonly stableDifferenceThreshold: number;
}
/**
 * Validate and materialize every ADB provider default.
 * @param config - Loader-parsed partial configuration.
 * @returns Complete configuration.
 */
export declare function resolveConfig(config: Config): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map