/** Deterministic one-action Phone executor with approval, stabilization, and verification. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { PhoneAction, PhoneActionError, PhoneCapture, PhoneDevice, PhoneUIElement, PhoneVerification, StableScreenResult } from '../core/index.ts';
import type { PhoneApprovalRequest } from './approval.ts';
import type { ResolvedConfig } from './config.ts';
/** Raw executor outcome before run counters, stuck detection, and model serialization. */
export interface ExecutedPhoneAction {
    /** Whether a device side effect was attempted. */
    readonly executed: boolean;
    /** Fresh state after execution or rejection. */
    readonly after: PhoneCapture;
    /** Verification based on before and after. */
    readonly verification: PhoneVerification;
    /** Structured execution failure. */
    readonly error?: PhoneActionError;
    /** Adaptive stabilization facts without duplicate screenshot bytes. */
    readonly stability?: Omit<StableScreenResult, 'screenshot'>;
    /** Semantic element resolved before execution. */
    readonly target?: PhoneUIElement;
}
/** Runtime progress exposed while one action is still unsettled. */
export type PhoneActionExecutionPhase = 'executing' | 'awaiting_approval' | 'stabilizing';
/** Executes one approved Phone action against one device handle. */
export declare class PhoneActionExecutor {
    private readonly ctx;
    private readonly config;
    /**
     * Create an executor using existing Harness services and run policy.
     * @param ctx - Context carrying optional approval.
     * @param config - Resolved action, stability, and approval limits.
     */
    constructor(ctx: Context, config: ResolvedConfig);
    /**
     * Execute one non-terminal action and always attempt a post-action observation.
     * @param agent - Agent whose current tool turn owns approval.
     * @param device - Reserved Phone device.
     * @param before - Fresh pre-action state.
     * @param action - Strict non-terminal action.
     * @param signal - Run and tool cancellation.
     * @param onApprovalRequired - Optional callback before the shared approval request opens.
     * @param onProgress - Optional callback publishing execution progress.
     * @returns Execution, stabilization, verification, and recoverable error facts.
     */
    execute(agent: Agent, device: PhoneDevice, before: PhoneCapture, action: Exclude<PhoneAction, {
        readonly type: 'finish';
    }>, signal: AbortSignal, onApprovalRequired?: (request: PhoneApprovalRequest) => void, onProgress?: (phase: PhoneActionExecutionPhase) => void): Promise<ExecutedPhoneAction>;
}
//# sourceMappingURL=executor.d.ts.map