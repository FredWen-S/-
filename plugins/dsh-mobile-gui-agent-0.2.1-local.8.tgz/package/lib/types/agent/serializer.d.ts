/** Compact model text for Phone observations and action outcomes. */
import type { PhoneActionResult, PhoneObservation, PhoneVisionObservation } from '../core/index.ts';
/**
 * Serialize one observation without raw XML or repeated empty attributes.
 * @param task - Current user task.
 * @param observation - JSON-safe current Phone state.
 * @param vision - Optional replaceable visual analysis.
 * @returns Token-optimized model text.
 */
export declare function serializePhoneObservation(task: string, observation: PhoneObservation, vision?: PhoneVisionObservation): string;
/**
 * Serialize one verified result beside its fresh observation.
 * @param result - Canonical action result.
 * @param observationText - Already serialized next observation.
 * @returns Compact action and evidence summary.
 */
export declare function serializePhoneActionResult(result: PhoneActionResult, observationText: string): string;
//# sourceMappingURL=serializer.d.ts.map