/** Fit model-facing screenshots to the Harness attachment limits. */
import type { PhoneScreenshot } from '../core/index.ts';
/** Screenshot bytes the attachment store accepts, plus the factor back to device pixels. */
export interface FittedScreenshot {
    /** PNG bytes, unchanged when the screenshot already fits. */
    readonly data: Uint8Array;
    /** Attached image width. */
    readonly width: number;
    /** Attached image height. */
    readonly height: number;
    /** Attached pixels per device pixel; 1 when the screenshot was not resized. */
    readonly scale: number;
}
/**
 * Downscale a screenshot whose longest side exceeds the attachment store's per-side limit.
 * Common phones (1080x2400 and up) exceed the default 2000px limit, which made every
 * attachment fail; the image is shrunk instead so the model can still see the screen.
 * @param screenshot - Device-resolution capture.
 * @param maxDimension - Longest side the attachment store admits.
 * @returns Attachable bytes and the scale the model must undo for coordinate actions.
 */
export declare function fitScreenshot(screenshot: PhoneScreenshot, maxDimension: number): Promise<FittedScreenshot>;
//# sourceMappingURL=screenshot.d.ts.map