/** Consequential Phone action classification and Harness approval. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { PhoneAction, PhoneObservation, PhoneUIElement } from '../core/index.ts';
/** Human-facing reason and impact for one consequential action. */
export interface PhoneApprovalRequest {
    /** Why runtime policy classified the action. */
    readonly reason: string;
    /** External or destructive effect that can occur. */
    readonly impact: string;
    /** Semantic target when one was resolved. */
    readonly target?: PhoneUIElement;
}
/**
 * Classify a semantic or coordinate action against visible UI text.
 * @param action - Proposed strict Phone action.
 * @param observation - Fresh pre-action state.
 * @returns Approval request for consequential effects, otherwise undefined.
 */
export declare function classifyPhoneAction(action: PhoneAction, observation: PhoneObservation): PhoneApprovalRequest | undefined;
/**
 * Request one-shot approval through the existing Harness service.
 * @param ctx - Context that may carry the optional approval service.
 * @param agent - Agent whose open tool turn owns the audit.
 * @param request - Classified reason and impact.
 * @param signal - Cooperative cancellation.
 */
export declare function requirePhoneApproval(ctx: Context, agent: Agent, request: PhoneApprovalRequest, signal: AbortSignal): Promise<void>;
//# sourceMappingURL=approval.d.ts.map