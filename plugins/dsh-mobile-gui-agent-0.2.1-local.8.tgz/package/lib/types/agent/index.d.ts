/** Iterative Android Phone run orchestration over the existing Harness Agent loop. */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { PhoneRunService } from '../core/index.ts';
import type { PhoneAction, PhoneDeviceId, PhoneDeviceInfo, PhoneExecutorResult, PhoneRunExecution, PhoneRunView, PhoneScreenshot, PhoneToolActionResult, PhoneToolObservation, ScheduledPhoneRun, SchedulePhoneRunRequest, StartPhoneRunRequest } from '../core/index.ts';
export { classifyPhoneAction, requirePhoneApproval } from './approval.ts';
export type { PhoneApprovalRequest } from './approval.ts';
export { resolveConfig } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { PhoneActionExecutor } from './executor.ts';
export type { ExecutedPhoneAction } from './executor.ts';
export { findStablePhoneElement, revalidateTapElementAction } from './elements.ts';
export type { RejectedTapElementAction, RevalidatedTapElementAction } from './elements.ts';
export { PHONE_AGENT_PROMPT, PHONE_TERMINAL_PROMPT } from './prompt.ts';
export { serializePhoneActionResult, serializePhoneObservation } from './serializer.ts';
export { PhoneStuckDetector } from './stuck-detector.ts';
export type { StuckRecord } from './stuck-detector.ts';
export { verifyPhoneAction } from './verifier.ts';
export type * from './events.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "phone-agent";
/** Deployment tunables for Phone Agent runs. */
export interface Config {
    /** Maximum non-observation actions in one run. */
    maxSteps?: number;
    /** Maximum run lifetime in milliseconds. */
    taskTimeoutMs?: number;
    /** Maximum one-action execution time. */
    actionTimeoutMs?: number;
    /** Consecutive verified failures before termination. */
    maxConsecutiveFailures?: number;
    /** Stable-screen poll interval. */
    stablePollMs?: number;
    /** Consecutive stable samples. */
    stableSamples?: number;
    /** Stable-screen timeout. */
    stableTimeoutMs?: number;
    /** Normalized screenshot difference treated as stable. */
    stableDifferenceThreshold?: number;
    /** Whether consequential actions require Harness approval. */
    approvalEnabled?: boolean;
    /** Whether screenshots enter model-visible attachment storage. */
    traceScreenshots?: boolean;
    /** Maximum recent step records retained in the live Remote view. */
    maxTraceSteps?: number;
    /**
     * How ordinary chat starts Phone work: `deferred` runs it on the chat Agent after its reply
     * (`phone_start_task`); `executor` runs it on a child-session executor Agent and returns the
     * result to the chat turn (`phone_run_task`, the Phase A prototype).
     */
    chatEntry?: 'deferred' | 'executor';
}
/** Public alias naming Phone run configuration. */
export type PhoneAgentConfig = Config;
/** Loader-visible Phone run configuration schema. */
export declare const Config: z<Config>;
/** Concrete active-run Provider layered over the existing Agent, Tool, Session, and approval plugins. */
export declare class PhoneAgentService extends PhoneRunService {
    /** Required Host services; approval and vision remain optional services. */
    static inject: string[];
    /** Loader-visible orchestration configuration. */
    static Config: z<Config>;
    private readonly config;
    private readonly executor;
    private readonly runs;
    private readonly lastViews;
    private readonly terminalFibers;
    private readonly devices;
    private readonly knownDevices;
    /** Chat-requested runs waiting for the requesting turn to end, with that turn's cancellation. */
    private readonly pendingStarts;
    private disposing;
    /**
     * Register the concrete `ctx.phoneRuns` provider.
     * @param ctx - Host context carrying Agent, Phone, attachment, LLM, prompt, and tool services.
     * @param config - Run limits, stability, approval, and trace policy.
     */
    constructor(ctx: Context, config?: Config);
    /**
     * List current provider devices for Remote and GUI selection.
     * @param signal - Cooperative cancellation.
     * @returns Current device records.
     */
    listDevices(signal?: AbortSignal): Promise<readonly PhoneDeviceInfo[]>;
    /**
     * Connect one wireless ADB address through the selected provider.
     * @param address - Valid provider endpoint.
     * @param signal - Cooperative cancellation.
     * @returns Connected record.
     */
    connect(address: string, signal?: AbortSignal): Promise<PhoneDeviceInfo>;
    /**
     * Start one Phone run on an idle Agent and unreserved device.
     * @param agent - Existing live Agent whose loop drives decisions.
     * @param request - Concrete device and natural-language task.
     * @param signal - Cooperative startup cancellation.
     * @returns Initial published run view.
     */
    start(agent: Agent, request: StartPhoneRunRequest, signal?: AbortSignal): Promise<PhoneRunView>;
    /** @inheritdoc */
    scheduleStart(agent: Agent, request: SchedulePhoneRunRequest, signal?: AbortSignal): Promise<ScheduledPhoneRun>;
    /** @inheritdoc */
    runInExecutor(parent: Agent, request: SchedulePhoneRunRequest, signal: AbortSignal): Promise<PhoneExecutorResult>;
    /** Resolve with an Agent's next terminal run view; dispose to stop listening. */
    private terminalView;
    /** Start an accepted chat request now that its turn has ended, reporting a late failure back to chat. */
    private startScheduled;
    /** @inheritdoc */
    observe(agent: Agent, signal: AbortSignal): Promise<PhoneToolObservation>;
    /** @inheritdoc */
    act(agent: Agent, action: PhoneAction, execution: PhoneRunExecution): Promise<PhoneToolActionResult>;
    /**
     * Return one Agent's bounded current run view.
     * @param agent - Exact run owner.
     * @returns View or undefined before a run starts.
     */
    getView(agent: Agent): PhoneRunView | undefined;
    /**
     * Capture a fresh GUI screenshot for one Agent's reserved device.
     * @param agent - Exact run owner.
     * @param signal - Cooperative cancellation.
     * @returns Fresh bounded screenshot.
     */
    getScreenshot(agent: Agent, deviceId?: PhoneDeviceId, signal?: AbortSignal): Promise<PhoneScreenshot>;
    /**
     * Pause after the in-flight action verifies and the current Agent activity reaches idle.
     * @param agent - Exact run owner.
     * @returns Paused run view.
     */
    pause(agent: Agent): Promise<PhoneRunView>;
    /**
     * Resume the same run with a fresh observation and plugin follow-up.
     * @param agent - Exact paused run owner.
     * @returns Running view.
     */
    resume(agent: Agent): Promise<PhoneRunView>;
    /**
     * Stop a run requested by the user and await Agent/device quiescence.
     * @param agent - Exact run owner.
     * @returns Terminal stopped view.
     */
    stop(agent: Agent): Promise<PhoneRunView>;
    /** Release a run whose owning Agent turn ended without a terminal Phone action. */
    private stopAbandonedRun;
    private actSerial;
    private finish;
    private rejectedAction;
    private limitResult;
    private settleStep;
    private prepareObservation;
    private imageCapable;
    private appendTerminal;
    private stopInternal;
    private finalizeWhenIdle;
    private finalize;
    /** Remove the safe post-run facade before mounting another active Phone scope. */
    private clearTerminalScope;
    private publishDeviceSnapshot;
    private publishDeviceState;
    private requireRun;
    private assertRunning;
    private runSignal;
    private updatePendingPhase;
    private enqueue;
    private view;
}
export default PhoneAgentService;
//# sourceMappingURL=index.d.ts.map