/** Stable semantic element matching across independently captured hierarchies. */
import type { PhoneActionError, PhoneObservation, PhoneUIElement } from '../core/index.ts';
import type { PhoneAction } from '../core/index.ts';
/** Successful rebinding of an observation-local semantic tap. */
export interface RevalidatedTapElementAction {
    /** Action rewritten to the fresh observation and element ids. */
    readonly action: Extract<PhoneAction, {
        readonly type: 'tap_element';
    }>;
    /** Unique matching element in the fresh hierarchy. */
    readonly target: PhoneUIElement;
}
/** Failed semantic tap rebinding. */
export interface RejectedTapElementAction {
    /** Structured stale-observation reason. */
    readonly error: PhoneActionError;
}
/**
 * Find one unique element using attributes that should survive text and list-order changes.
 * @param target - Element from an earlier observation.
 * @param elements - Elements in a fresh observation.
 * @returns The unique stable match, otherwise undefined.
 */
export declare function findStablePhoneElement(target: PhoneUIElement, elements: readonly PhoneUIElement[]): PhoneUIElement | undefined;
/**
 * Revalidate only a semantic tap target instead of rejecting unrelated screen changes.
 * @param action - Model-authored semantic tap.
 * @param visible - Last observation actually shown to the model.
 * @param fresh - Fresh pre-action observation.
 * @returns A fresh observation-local action or a structured stale rejection.
 */
export declare function revalidateTapElementAction(action: Extract<PhoneAction, {
    readonly type: 'tap_element';
}>, visible: PhoneObservation | undefined, fresh: PhoneObservation): RevalidatedTapElementAction | RejectedTapElementAction;
//# sourceMappingURL=elements.d.ts.map