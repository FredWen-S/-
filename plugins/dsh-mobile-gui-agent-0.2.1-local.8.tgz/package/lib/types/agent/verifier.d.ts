/** Deterministic before/after Phone action verification. */
import type { PhoneAction, PhoneObservation, PhoneUIElement, PhoneVerification } from '../core/index.ts';
/**
 * Compare independent UI evidence after one device action.
 * @param before - Fresh pre-action observation.
 * @param action - Executed action.
 * @param after - Fresh stable post-action observation.
 * @param target - Semantic target resolved before execution, when any.
 * @returns Verification success, change fact, and evidence statements.
 */
export declare function verifyPhoneAction(before: PhoneObservation, action: PhoneAction, after: PhoneObservation, target?: PhoneUIElement): PhoneVerification;
//# sourceMappingURL=verifier.d.ts.map