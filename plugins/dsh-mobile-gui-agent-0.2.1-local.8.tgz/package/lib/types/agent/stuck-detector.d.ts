/** Bounded Phone action/state cycle detection. */
import type { PhoneAction, PhoneStuckStatus } from '../core/index.ts';
/** One history item retained by the deterministic stuck detector. */
export interface StuckRecord {
    /** Executed or rejected action. */
    readonly action: PhoneAction;
    /** Pre-action combined state signature. */
    readonly before: string;
    /** Post-action combined state signature. */
    readonly after: string;
    /** Whether verification succeeded. */
    readonly success: boolean;
    /** Structured error code when execution failed before verification. */
    readonly errorCode?: string;
}
/** Recent-history detector for repeated actions, unchanged failures, cycles, and device errors. */
export declare class PhoneStuckDetector {
    private readonly history;
    /**
     * Record one result and diagnose the bounded recent suffix.
     * @param record - Canonical action and before/after facts.
     * @returns Stuck status and a deterministic recovery category.
     */
    record(record: StuckRecord): PhoneStuckStatus;
}
//# sourceMappingURL=stuck-detector.d.ts.map