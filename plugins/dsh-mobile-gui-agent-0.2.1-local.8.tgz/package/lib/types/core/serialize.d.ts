/** Serialize one compact UI element for hierarchy and model output. */
import type { PhoneUIElement } from './types.ts';
export declare function serializePhoneElement(element: PhoneUIElement): string;
//# sourceMappingURL=serialize.d.ts.map