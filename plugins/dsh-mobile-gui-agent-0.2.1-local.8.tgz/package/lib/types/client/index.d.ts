/** Phone Agent browser plugin contributing one session view through standard slots. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type PhoneAgentKey } from './locales.ts';
export { PhoneAgentView } from './PhoneAgentView.tsx';
export type { PhoneAgentPanelProps, PhoneAgentViewProps } from './PhoneAgentView.tsx';
export { MobileLauncher } from './MobileLauncher.tsx';
export type { MobileLauncherProps } from './MobileLauncher.tsx';
export { describePhoneAction, phoneActionOverlay } from './view-model.ts';
export type { PhoneOverlay } from './view-model.ts';
export { buildSemanticAgentSteps, semanticRunTitle } from './semantic-steps.ts';
export type { AgentStepStatus, AgentStepType, SemanticAgentStep, SemanticVerification } from './semantic-steps.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Phone Agent tab copy. */
        'phone-agent': PhoneAgentKey;
    }
}
/** Required standard client services and the Typert Remote carrier. */
export declare const inject: string[];
/**
 * Register the Phone Agent tab and bind Remote calls to each owning session.
 * @param ctx - Client Cordis root.
 */
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map