/** Strict Phone action tool schema and wire conversion. */
import type { PhoneAction } from '../core/index.ts';
import type { ObjectValueSchemaSpec } from '@deepseek-ai/dsh-tools';
/** Phone key names accepted on the model wire. */
export declare const PHONE_KEYS: readonly ["enter", "delete", "tab", "escape", "volume_up", "volume_down", "power"];
/** Exact-one schema for all model-selectable Phone actions. */
export declare const PHONE_ACTION_SCHEMA: {
    readonly oneOf: readonly [ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec];
};
/** Complete `phone_act` parameter root. */
export declare const PHONE_ACTION_PARAMETERS: {
    readonly action: {
        readonly oneOf: readonly [ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec, ObjectValueSchemaSpec];
        readonly required: true;
    };
};
/**
 * Convert one schema-validated wire action into the shared canonical union.
 * @param value - Value accepted by {@link PHONE_ACTION_SCHEMA}.
 * @returns Canonical camelCase action.
 */
export declare function parsePhoneAction(value: unknown): PhoneAction;
//# sourceMappingURL=schema.d.ts.map