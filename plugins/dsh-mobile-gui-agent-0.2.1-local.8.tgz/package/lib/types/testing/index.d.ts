/** Deterministic scripted Phone provider for unit and assembled tests. */
import { PhoneDeviceRegistry } from '../core/index.ts';
import type { PhoneCapture, PhoneDevice, PhoneDeviceId as PhoneDeviceIdType, PhoneDeviceInfo, PhoneHierarchy, PhoneKey, PhoneScreenshot, PhoneShellRequest, PhoneUIElement, StableScreenOptions, StableScreenResult } from '../core/index.ts';
import type { Context } from '@deepseek-ai/cordis';
/** Low-level operation recorded by a fake device. */
export type FakePhoneOperation = {
    readonly type: 'tap';
    readonly x: number;
    readonly y: number;
} | {
    readonly type: 'long_press';
    readonly x: number;
    readonly y: number;
    readonly durationMs: number;
} | {
    readonly type: 'swipe';
    readonly x1: number;
    readonly y1: number;
    readonly x2: number;
    readonly y2: number;
    readonly durationMs: number;
} | {
    readonly type: 'input_text';
    readonly text: string;
} | {
    readonly type: 'replace_text';
    readonly text: string;
} | {
    readonly type: 'setup_unicode_input';
} | {
    readonly type: 'press_key';
    readonly key: PhoneKey;
} | {
    readonly type: 'back';
} | {
    readonly type: 'home';
} | {
    readonly type: 'open_app';
    readonly packageName: string;
} | {
    readonly type: 'shell';
    readonly request: PhoneShellRequest;
};
/** One state transition accepted by a scripted fake screen. */
export interface FakePhoneTransition {
    /** Exact low-level operation expected. */
    readonly operation: FakePhoneOperation;
    /** Destination screen id. */
    readonly to: string;
    /** Optional failure injected before the transition. */
    readonly error?: Error;
}
/** One named screen and its accepted transitions. */
export interface FakePhoneScreen {
    /** Screen id referenced by transitions. */
    readonly id: string;
    /** Coherent capture returned while this screen is active. */
    readonly capture: PhoneCapture;
    /** Operations accepted from this screen. */
    readonly transitions: readonly FakePhoneTransition[];
}
/** Script for one fake Android device. */
export interface FakePhoneScript {
    /** Device record returned by discovery. */
    readonly device: PhoneDeviceInfo;
    /** Initial screen id. */
    readonly initialScreen: string;
    /** Complete finite screen set. */
    readonly screens: readonly FakePhoneScreen[];
}
/** Deterministic fake device with an observable operation ledger. */
export declare class FakePhoneDevice implements PhoneDevice {
    private readonly script;
    /** Accepted operations in execution order. */
    readonly operations: FakePhoneOperation[];
    private readonly screens;
    private current;
    /**
     * Create one scripted device.
     * @param script - Finite screen graph and discovery record.
     */
    constructor(script: FakePhoneScript);
    /** Bound fake device identity. */
    get id(): PhoneDeviceIdType;
    /** @inheritdoc */
    getState(): Promise<PhoneCapture>;
    /** @inheritdoc */
    screenshot(): Promise<PhoneScreenshot>;
    /** @inheritdoc */
    getUIHierarchy(): Promise<PhoneHierarchy>;
    /** @inheritdoc */
    tap(x: number, y: number): Promise<void>;
    /** @inheritdoc */
    longPress(x: number, y: number, durationMs: number): Promise<void>;
    /** @inheritdoc */
    swipe(x1: number, y1: number, x2: number, y2: number, durationMs: number): Promise<void>;
    /** @inheritdoc */
    inputText(text: string): Promise<void>;
    /** @inheritdoc */
    replaceText(text: string): Promise<void>;
    /** @inheritdoc */
    setupUnicodeInput(): Promise<void>;
    /** @inheritdoc */
    pressKey(key: PhoneKey): Promise<void>;
    /** @inheritdoc */
    back(): Promise<void>;
    /** @inheritdoc */
    home(): Promise<void>;
    /** @inheritdoc */
    openApp(packageName: string): Promise<void>;
    /** @inheritdoc */
    shell(request: PhoneShellRequest): Promise<string>;
    /** @inheritdoc */
    wait(ms: number, signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    waitForStableScreen(_options: StableScreenOptions): Promise<StableScreenResult>;
    private perform;
    private screen;
}
/** `ctx.phone` provider whose devices are finite scripted state machines. */
export declare class FakePhoneDeviceRegistry extends PhoneDeviceRegistry {
    private readonly devices;
    /**
     * Register fake scripts as one Phone provider.
     * @param ctx - Cordis context receiving `ctx.phone`.
     * @param scripts - One script per fake device.
     */
    constructor(ctx: Context, scripts: readonly FakePhoneScript[]);
    /** @inheritdoc */
    list(): Promise<readonly PhoneDeviceInfo[]>;
    /** @inheritdoc */
    connect(): Promise<PhoneDeviceInfo>;
    /** @inheritdoc */
    open(id: PhoneDeviceIdType): Promise<PhoneDevice>;
    /**
     * Return a fake device for ledger assertions.
     * @param id - Scripted device identity.
     * @returns Exact fake device instance.
     */
    device(id: PhoneDeviceIdType): FakePhoneDevice;
}
/** Input for the compact fake-capture builder. */
export interface FakeCaptureInput {
    /** Device identity. */
    readonly deviceId?: PhoneDeviceIdType;
    /** Display width. */
    readonly width?: number;
    /** Display height. */
    readonly height?: number;
    /** Foreground package. */
    readonly foregroundPackage?: string;
    /** Foreground activity. */
    readonly activity?: string;
    /** Retained UI elements. */
    readonly elements?: readonly PhoneUIElement[];
    /** Unique semantic state label. */
    readonly state?: string;
}
/**
 * Build a coherent small capture for scripted tests.
 * @param input - Optional geometry, app identity, elements, and state label.
 * @returns Capture with deterministic signatures and valid PNG header bytes.
 */
export declare function createFakeCapture(input?: FakeCaptureInput): PhoneCapture;
//# sourceMappingURL=index.d.ts.map