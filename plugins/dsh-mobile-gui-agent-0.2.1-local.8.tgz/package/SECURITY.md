# Security Policy

## Supported versions

Security fixes are applied to the latest released version of `dsh-mobile-gui-agent`.

## Reporting a vulnerability

Do not open a public issue for a vulnerability that could allow unintended Android actions, approval bypass, arbitrary shell execution, credential disclosure, or access to captured screen data. Contact the repository maintainer privately and include the affected version, reproduction steps, impact, and any proposed mitigation.

Avoid including API keys, account credentials, personal messages, or unredacted device screenshots in a report. Revoke any credential that may have been exposed during testing.

## Operator responsibilities

Run the plugin on a dedicated test device and non-production accounts until its behavior is understood. Pin Git installations to an audited commit, keep approval enabled, and review every approval request before allowing the action once.
