# Unicode Helper Onboarding Implementation Plan

> **For Codex:** Execute this plan inline with test-first changes. Do not commit, push, tag, publish, or touch a real device unless the user separately authorizes it.

**Goal:** Let a Phone run recover from a missing Unicode helper through an explicit Harness approval, while preserving the user's current input method and avoiding the malformed-call and unknown-foreground failures seen in `session.jsonl2`.

**Architecture:** Keep the helper APK user-supplied and configured by an absolute host path so the plugin neither downloads unreviewed software nor accepts a model-authored path. Add one model action that requests Harness approval, installs the configured APK only when absent, and proves it can temporarily select the helper before restoring the previous IME. Unicode entry may then temporarily select the approved helper for that run and always restore the previous IME. Add narrow wire compatibility for one accidental nested `action` object and derive a missing foreground package from unambiguous UI resource IDs.

**Tech Stack:** TypeScript, Cordis/Harness tools and approval service, direct-argv ADB, Vitest, pnpm.

---

### Task 1: Approved Unicode helper setup

**Files:**

- Modify: `src/core/types.ts`
- Modify: `src/adb/index.ts`
- Modify: `src/adb/config.ts`
- Modify: `src/adb/adb-device.ts`
- Modify: `src/adb/unicode-ime.ts`
- Modify: `src/agent/approval.ts`
- Modify: `src/agent/executor.ts`
- Modify: `src/agent/verifier.ts`
- Modify: `src/agent/prompt.ts`
- Modify: `src/agent/stuck-detector.ts`
- Modify: `src/testing/index.ts`
- Test: `tests/adb/adb-device.spec.ts`
- Test: `tests/agent/approval.spec.ts`
- Test: `tests/agent/executor.spec.ts`

- [x] Add failing tests for `setup_unicode_input`, mandatory approval classification, configured APK installation, temporary IME selection/restoration, and a no-side-effect failure when no APK path is configured.
- [x] Add optional absolute `adb.unicodeImeApkPath` configuration and validate it without resolving model-provided paths.
- [x] Add the setup action to `PhoneAction`/`PhoneDevice`, fake-device support, dispatch, verification, UI descriptions, and stuck normalization.
- [x] Install only after approval, verify the helper, restore the previous IME after the setup probe and each Unicode broadcast, and report preflight capability failures as `executed: false`.
- [x] Run the focused ADB and Agent tests.

### Task 2: Tool-call compatibility and model guidance

**Files:**

- Modify: `src/tools/schema.ts`
- Modify: `src/tools/index.ts`
- Modify: `src/agent/prompt.ts`
- Test: `tests/tools/schema.spec.ts`

- [x] Reproduce the single extra `{ action: ... }` wrapper from the log in a failing schema test.
- [x] Accept and unwrap exactly one legacy nested action while retaining strict rejection of unknown fields and deeper nesting.
- [x] Make the tool description show the direct action shape and instruct the Agent to run setup once before non-ASCII input.
- [x] Run the focused schema tests.

### Task 3: Foreground-package fallback

**Files:**

- Modify: `src/adb/foreground.ts`
- Modify: `src/adb/adb-device.ts`
- Test: `tests/adb/foreground.spec.ts`

- [x] Add failing tests for an unambiguous package inferred from UI resource IDs and for an ambiguous tie that must remain unknown.
- [x] Use the hierarchy inference only when `dumpsys` produced no foreground package; do not invent an activity.
- [x] Run the focused foreground tests.

### Task 4: Documentation and full verification

**Files:**

- Modify: `README.md`
- Modify: `docs/README.zh.md`
- Modify generated tracked output under: `lib/`

- [x] Document the reviewed helper APK path, approval behavior, temporary IME restoration, and fallback when configuration is absent.
- [x] Run `pnpm run check` to typecheck, rebuild tracked `lib/`, run all tests, and verify package contents.
- [x] Run `pnpm pack` and inspect the generated tarball summary.
- [x] Review `git diff --check`, `git status --short --branch`, and the complete diff. Leave all changes uncommitted for user review.
