# Phone Input and Verification Fixes Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Unicode text entry work through an explicitly user-installed ADB Keyboard helper, prevent animated screens from falsely verifying text edits, revalidate semantic tap targets locally, and normalize cancellation and HyperOS diagnostics.

**Architecture:** Keep all ADB commands provider-owned and direct-argv. Add one read-only helper-IME capability probe plus Base64 broadcast transport, expose a model-level `replace_text` action, and centralize stable element matching so stale checks and text verification use the same resource/class/description/bounds identity instead of whole-screen signatures.

**Tech Stack:** TypeScript 6, Node.js 22+, Android ADB shell commands, Vitest, pnpm.

## Global Constraints

- Do not install, enable, or switch an Android IME from the plugin; those operations require explicit user authorization outside a running task.
- Keep `PHONE_UNICODE_INPUT_UNSUPPORTED` when the supported helper is unavailable or inactive.
- Do not connect to or mutate a real device while implementing or testing these changes.
- Preserve the public protocol names `PhoneDevice`, `phone_observe`, and `phone_act`.
- Rebuild and commit tracked `lib/` output whenever source output changes.
- Do not push, tag, publish, or release.

---

### Task 1: Unicode input helper and atomic text replacement

**Files:**
- Create: `src/adb/unicode-ime.ts`
- Modify: `src/adb/adb-device.ts`
- Modify: `src/core/types.ts`
- Modify: `src/tools/schema.ts`
- Modify: `src/testing/index.ts`
- Modify: `src/agent/executor.ts`
- Modify: `src/agent/stuck-detector.ts`
- Modify: `src/agent/prompt.ts`
- Modify: `src/client/view-model.ts`
- Test: `tests/adb/adb-device.spec.ts`
- Test: `tests/tools/schema.spec.ts`
- Test: `tests/client/view-model.client.spec.ts`

**Interfaces:**
- Consumes: `AdbClient.text(argv, maxBytes, signal)` and the existing focused Android input.
- Produces: `PhoneDevice.replaceText(text, signal)`, `PhoneAction` variant `{ type: 'replace_text'; text: string }`, and helper detection for `com.android.adbkeyboard/.AdbIME`.

- [ ] **Step 1: Write failing ADB and schema tests**

```ts
it('sends Unicode as UTF-8 Base64 only when ADB Keyboard is installed, enabled, and selected', async () => {
  await device.inputText('\u4e2d\u6587')
  expect(shellCalls.at(-1)).toEqual([
    '-s', 'fake', 'shell', 'am', 'broadcast', '-a', 'ADB_INPUT_B64',
    '-p', 'com.android.adbkeyboard', '--es', 'msg', '5Lit5paH',
  ])
})

it('rejects Unicode without installing or switching an IME', async () => {
  await expect(device.inputText('\u4e2d\u6587')).rejects.toMatchObject({
    code: 'PHONE_UNICODE_INPUT_UNSUPPORTED',
  })
  expect(shellCalls.flat()).not.toContain('set')
})

it('accepts replace_text with an empty replacement', () => {
  const action = { type: 'replace_text', text: '' }
  expect(validateArgs(PHONE_ACTION_PARAMETERS, { action })).toEqual([])
  expect(parsePhoneAction(action)).toEqual(action)
})
```

- [ ] **Step 2: Run the focused tests and verify they fail**

Run: `pnpm vitest run tests/adb/adb-device.spec.ts tests/tools/schema.spec.ts tests/client/view-model.client.spec.ts`

Expected: FAIL because Unicode is rejected and `replace_text` is absent.

- [ ] **Step 3: Implement helper detection, Base64 broadcasts, and replacement**

```ts
export const ADB_KEYBOARD = {
  component: 'com.android.adbkeyboard/.AdbIME',
  packageName: 'com.android.adbkeyboard',
  inputAction: 'ADB_INPUT_B64',
  clearAction: 'ADB_CLEAR_TEXT',
} as const

export function adbKeyboardAvailability(
  installed: string,
  enabled: string,
  selected: string,
): 'ready' | 'not-installed' | 'not-enabled' | 'not-selected' {
  if (!containsComponent(installed, ADB_KEYBOARD.component)) return 'not-installed'
  if (!containsComponent(enabled, ADB_KEYBOARD.component)) return 'not-enabled'
  return containsComponent(selected, ADB_KEYBOARD.component) ? 'ready' : 'not-selected'
}
```

`AdbPhoneDevice.inputText` keeps native `input text` for printable ASCII. Unicode first probes `ime list -s`, `settings get secure enabled_input_methods`, and `settings get secure default_input_method`, then broadcasts UTF-8 Base64 only when the helper is ready. `replaceText` probes before mutating for Unicode, uses `ADB_CLEAR_TEXT` plus Base64 with the active helper, and otherwise uses Android `input keycombination KEYCODE_CTRL_LEFT KEYCODE_A`, Delete, and native ASCII input. No code path invokes `adb install`, `ime enable`, or `ime set`.

- [ ] **Step 4: Wire `replace_text` through the action stack and prompt**

```ts
export type PhoneAction =
  | { readonly type: 'input_text'; readonly text: string }
  | { readonly type: 'replace_text'; readonly text: string }
  // existing actions remain unchanged

case 'replace_text':
  await device.replaceText(action.text, signal)
  return
```

Add a prompt rule telling the model to prefer `replace_text` over repeated Delete presses and to immediately `finish(success=false)` after `PHONE_UNICODE_INPUT_UNSUPPORTED` rather than retrying.

- [ ] **Step 5: Run the focused tests and verify they pass**

Run: `pnpm vitest run tests/adb/adb-device.spec.ts tests/tools/schema.spec.ts tests/client/view-model.client.spec.ts`

Expected: PASS.

### Task 2: Semantic text verification and local target revalidation

**Files:**
- Create: `src/agent/elements.ts`
- Modify: `src/agent/verifier.ts`
- Modify: `src/agent/index.ts`
- Modify: `src/agent/executor.ts`
- Test: `tests/agent/verifier.spec.ts`
- Test: `tests/agent/target-revalidation.spec.ts`

**Interfaces:**
- Consumes: model-visible and fresh `PhoneObservation` objects.
- Produces: `findStablePhoneElement(target, elements)` and `revalidateTapElementAction(action, visible, fresh)`.

- [ ] **Step 1: Write failing verification and revalidation tests**

```ts
it('does not verify Delete from an unrelated screenshot animation', () => {
  const result = verifyPhoneAction(
    observation({ elements: [focusedField('query')] }),
    { type: 'press_key', key: 'delete' },
    observation({ elements: [focusedField('query')], screenshotSignature: 'animated' }),
  )
  expect(result).toMatchObject({ success: false, changed: true })
})

it('rebinds an unchanged target after unrelated dynamic content changes', () => {
  const result = revalidateTapElementAction(action, visible, fresh)
  expect(result).toMatchObject({ action: { elementId: 9 } })
})
```

- [ ] **Step 2: Run focused agent tests and verify they fail**

Run: `pnpm vitest run tests/agent/verifier.spec.ts tests/agent/target-revalidation.spec.ts`

Expected: FAIL because screenshot changes currently imply success and the local revalidator does not exist.

- [ ] **Step 3: Implement stable element matching and semantic text verification**

```ts
export function findStablePhoneElement(
  target: PhoneUIElement,
  elements: readonly PhoneUIElement[],
): PhoneUIElement | undefined {
  const matches = elements.filter(element =>
    element.className === target.className
    && element.resourceId === target.resourceId
    && element.contentDescription === target.contentDescription
    && sameBounds(element.bounds, target.bounds))
  return matches.length === 1 ? matches[0] : undefined
}
```

For `press_key(delete)`, `input_text`, and `replace_text`, verification must compare the focused editable field before and after. Delete succeeds only when the text length decreases; input succeeds only when text changes; replacement succeeds only when the resulting text equals the requested text. Whole-screen change remains diagnostic `changed` evidence but cannot prove these text actions.

- [ ] **Step 4: Replace whole-screen stale rejection with local revalidation**

```ts
const revalidated = revalidateTapElementAction(action, visible, before.observation)
if ('error' in revalidated) return this.rejectedAction(/* PHONE_STALE_OBSERVATION */)
const executableAction = revalidated.action
```

The revalidator still rejects mismatched observation IDs, missing original targets, moved targets, changed resource IDs/classes/descriptions, and ambiguous matches. It permits unrelated screenshot/UI signature changes and rebinds observation-local element IDs before execution.

- [ ] **Step 5: Run focused agent tests and verify they pass**

Run: `pnpm vitest run tests/agent/verifier.spec.ts tests/agent/target-revalidation.spec.ts tests/agent/executor.spec.ts tests/agent/loop.integration.spec.ts`

Expected: PASS.

### Task 3: Cancellation normalization and HyperOS diagnostics

**Files:**
- Modify: `src/core/error.ts`
- Modify: `src/adb/adb-client.ts`
- Modify: `src/adb/adb-device.ts`
- Modify: `src/adb/foreground.ts`
- Create: `tests/core/error.spec.ts`
- Create: `tests/adb/foreground.spec.ts`
- Create: `tests/fixtures/hyperos-window.txt`
- Create: `tests/fixtures/hyperos-input-method.txt`

**Interfaces:**
- Consumes: arbitrary `AbortSignal.reason` values and MIUI/HyperOS `dumpsys` text.
- Produces: `phoneAbortError(signal, fallback)` plus expanded foreground and IME visibility parsing.

- [ ] **Step 1: Write failing cancellation and parser tests**

```ts
it('normalizes an object cancellation reason without object stringification', () => {
  const controller = new AbortController()
  controller.abort({ kind: 'user' })
  expect(phoneAbortError(controller.signal, 'Phone action was cancelled')).toMatchObject({
    code: 'PHONE_ACTION_TIMEOUT',
    message: 'Phone action was cancelled (user)',
  })
})

it('parses HyperOS focused-window and IME visibility fixtures', () => {
  expect(parseForegroundState(windowFixture)).toMatchObject({ packageName: 'com.taobao.taobao' })
  expect(parseKeyboardVisible(inputMethodFixture)).toBe(true)
})
```

- [ ] **Step 2: Run focused diagnostics tests and verify they fail**

Run: `pnpm vitest run tests/core/error.spec.ts tests/adb/foreground.spec.ts`

Expected: FAIL because object abort reasons and HyperOS fields are not normalized or parsed.

- [ ] **Step 3: Normalize abort reasons at ADB boundaries**

```ts
export function phoneAbortError(signal: AbortSignal, fallback: string): PhoneError {
  const reason = signal.reason
  const suffix = isRecord(reason) && typeof reason.kind === 'string' ? ` (${reason.kind})` : ''
  const message = reason instanceof Error && reason.message.length > 0 ? reason.message : `${fallback}${suffix}`
  return reason instanceof PhoneError ? reason : new PhoneError('PHONE_ACTION_TIMEOUT', message, reason)
}
```

Use this helper instead of `signal.throwIfAborted()` and for aborted ADB text/binary commands so plain objects never escape into tool serialization.

- [ ] **Step 4: Expand foreground and keyboard parsing**

Parse `mFocusedWindow`/`mResumedActivity` components, use `dumpsys activity activities` as a foreground fallback, and interpret `mImeWindowVis` with Android's visible bit. Feed both input-method and window diagnostics into keyboard visibility parsing.

- [ ] **Step 5: Run focused diagnostics tests and verify they pass**

Run: `pnpm vitest run tests/core/error.spec.ts tests/adb/foreground.spec.ts tests/adb/hierarchy-retry.spec.ts`

Expected: PASS.

### Task 4: Full verification, generated output, and atomic commit

**Files:**
- Modify: generated `lib/**` files produced by the repository build
- Verify: all files changed by Tasks 1-3

**Interfaces:**
- Consumes: completed source and tests.
- Produces: a checked, package-verifiable standalone plugin commit on `dev`.

- [ ] **Step 1: Run the complete repository check**

Run: `pnpm run check`

Expected: TypeScript checks, build, unit/integration tests, and package verification all pass; tracked `lib/` reflects source.

- [ ] **Step 2: Build and inspect the package tarball**

Run: `pnpm pack`

Expected: a local `.tgz` is produced and package verification succeeds. Inspect its file listing, then leave the untracked tarball out of Git.

- [ ] **Step 3: Review the complete diff and secrets surface**

Run: `git status --short --branch`, `git diff --stat`, `git diff`, and `git diff --cached --stat`.

Expected: only task source, tests, fixtures, plan, and generated `lib/` output are present; no credentials, private screenshots, device data, or unrelated changes appear.

- [ ] **Step 4: Stage exact paths using the atomic-commit skill**

```bash
git add -- docs/superpowers/plans/2026-08-14-phone-input-and-verification-fixes.md src/adb/adb-client.ts src/adb/adb-device.ts src/adb/foreground.ts src/adb/unicode-ime.ts src/agent/elements.ts src/agent/executor.ts src/agent/index.ts src/agent/prompt.ts src/agent/stuck-detector.ts src/agent/verifier.ts src/client/view-model.ts src/core/error.ts src/core/types.ts src/testing/index.ts src/tools/schema.ts tests/adb/adb-device.spec.ts tests/adb/foreground.spec.ts tests/agent/target-revalidation.spec.ts tests/agent/verifier.spec.ts tests/client/view-model.client.spec.ts tests/core/error.spec.ts tests/fixtures/hyperos-input-method.txt tests/fixtures/hyperos-window.txt tests/tools/schema.spec.ts lib
```

- [ ] **Step 5: Review staged content and create one complete bug-fix commit**

Run: `git diff --cached --stat`, `git diff --cached`, then commit with a subject no longer than 72 characters and a body explaining the Unicode transport, semantic verification, local revalidation, and cancellation/diagnostics fixes.

Expected: one buildable commit containing implementation, regression tests, fixtures, documentation plan, and generated artifacts.

- [ ] **Step 6: Verify the post-commit repository state**

Run: `git status --short --branch` and `git show --stat --oneline --decorate HEAD`.

Expected: branch `dev` points to the new local commit; only intentionally untracked local package artifacts, if retained, remain; nothing is pushed or released.
