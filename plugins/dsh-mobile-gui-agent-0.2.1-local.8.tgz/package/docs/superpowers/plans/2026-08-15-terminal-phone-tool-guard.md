# Terminal Phone Tool Guard Implementation Plan

> **For Codex:** Execute this plan inline with test-driven development. Do not delegate, commit, push, tag, or release without explicit user authorization.

**Goal:** Prevent `UNKNOWN_TOOL` when a model tries to reuse `phone_act` or `phone_observe` after a Mobile task has already reached a terminal state.

**Architecture:** Keep the real phone tools scoped to an active `PhoneRun`. When that scope is disposed, install an agent-local terminal guard scope with safe, no-op tools using the same public names and schemas. A stale tool call then receives a deterministic `PHONE_RUN_NOT_ACTIVE` result instead of reaching the Harness unknown-tool path. Starting a new Mobile run disposes the guard before mounting the real tools.

**Tech Stack:** TypeScript, DeepSeek Harness plugin APIs, Vitest, pnpm.

---

## Task 1: Specify the terminal behavior

**Files:**

- Modify: `tests/agent/loop.integration.spec.ts`
- Modify: `tests/agent/prompt.spec.ts`
- Modify: `src/agent/prompt.ts`

1. Add an integration scenario that ends a Phone run, sends a normal chat follow-up such as `我批准`, and has the mock model attempt `phone_act` again.
2. Assert the post-terminal request still has safe definitions for `phone_act` and `phone_observe`.
3. Assert the stale call returns `PHONE_RUN_NOT_ACTIVE`, never `UNKNOWN_TOOL`, and does not mutate the fake device.
4. Add prompt assertions documenting that chat approval cannot resume a terminal Phone task and that a new task must be started from Mobile.
5. Run the focused tests and confirm they fail before implementation.

## Task 2: Add safe inactive phone tools

**Files:**

- Modify: `src/tools/index.ts`
- Modify: `src/agent/index.ts`
- Modify: `src/agent/prompt.ts`

1. Reuse the public phone-tool input/output schemas to register inactive implementations of `phone_act` and `phone_observe`.
2. Make both implementations perform no device access and return a structured `PHONE_RUN_NOT_ACTIVE` payload with the prior terminal status and recovery instruction.
3. Add a terminal system-prompt section that tells the model not to treat ordinary chat text as a native approval response.
4. Track one terminal guard fiber per agent.
5. Dispose the guard before a new Phone run starts, when its agent is disposed, and when the service is torn down.
6. Skip guard creation during service teardown and failed startup so no stale scope leaks.
7. Run the focused tests and confirm the regression passes.

## Task 3: Verify lifecycle and generated output

**Files:**

- Modify generated files under: `lib/`

1. Run the full `pnpm run check` pipeline (typecheck, build, unit tests, fake-device integration, and package verification).
2. Inspect the worktree diff to ensure only intended source, test, plan, and rebuilt `lib/` changes were added on top of the user's existing changes.
3. Run `pnpm pack` and inspect the package result.
4. Report exact checks, branch/commit, device access, publishing status, and local-only artifacts. Do not touch a real Android device for this regression.
