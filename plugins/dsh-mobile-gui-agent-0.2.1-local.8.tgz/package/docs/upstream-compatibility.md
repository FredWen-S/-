# Upstream compatibility audit

This repository was exported as a standalone DeepSeek Harness plugin against upstream commit `47f943859bef60e4160492346772ded9b24f765a` (`0.1.0-rc.5`). Its dependency installation resolves and passes the test suite with the published `0.1.0-rc.6` packages.

## Publication requirements

| Upstream requirement | Implementation |
| --- | --- |
| An installable plugin is an npm bundle package | `package.json` declares `dsh.bundle.patch` |
| A bundle patch is a YAML array | `cordis.patch.yml` contains one `insert` operation |
| Loader rows resolve the installed package name | The row uses `name: dsh-mobile-gui-agent` |
| Browser plugins declare their client dependency graph | `package.json` declares `dsh.client`, `platform: web`, and required injected packages |
| Host Remote descriptors use the package `./typert` export | `./typert` ships a checked-in generated Host face owned by `dsh-mobile-gui-agent` |
| Browser Remote calls mount the paired generated contribution | The browser client mounts `./remote` through `ctx.remote.$mount()` |
| Out-of-tree packages cannot use workspace ranges | No dependency section contains `workspace:` |
| Git installs need built output or an approved prepare script | The repository tracks `lib/`; it has no `prepare` script |
| Plugin behavior uses Cordis lifecycle effects | The root Loader row owns all nested Provider, Consumer, Remote, tool, event, and client registrations |
| New behavior extends the Agent through plugins | The upstream Agent loop is unchanged; Phone tools and prompt are Agent-scoped plugins |

## Standalone adaptation

The integrated prototype originally used custom `phone/*` Session event types and a generated Session projection. An external package cannot extend the upstream build-time `KNOWN_SESSION_EVENT_TYPES` table without modifying Harness itself. This standalone plugin therefore uses standard Harness user/tool Session events for model-visible history, Cordis events for live diagnostics, and a bounded `PhoneRunView` Remote for the Web GUI. The last terminal view is retained until the owning Agent is disposed or a new Phone run starts.

This is an intentional compatibility change: installing the plugin does not alter Harness source, generated catalogs, the Agent loop, or the Session on-disk format.

## Verification commands

```bash
pnpm install
pnpm run typecheck
pnpm run build
pnpm run test
pnpm run verify:package
pnpm pack
```

The final acceptance also installs the generated tarball into an isolated published Harness `0.1.0-rc.6` Web profile, inspects `--dump-config`, loads the host and browser plugin graphs without the source monorepo's Phone packages, opens **mobile_gui_agent**, and checks the browser error log. Upstream Harness deliberately hides conversation-view tabs while a session is still on the empty new-conversation hero, so the plugin also registers a blank-session toolbar launcher. The documented recommended flow sends one short ordinary message first, then uses the regular **mobile_gui_agent** tab and enters the real phone command only in its **Task** field.
