/** Opaque Phone runtime identities. */

import type { Branded } from '@deepseek-ai/dsh-brand'

/** Identifies one Android device in a Phone provider. */
export type PhoneDeviceId = Branded<'PhoneDeviceId'>
/** Identifies one model-visible observation. */
export type PhoneObservationId = Branded<'PhoneObservationId'>
/** Identifies one active or historical Phone run. */
export type PhoneRunId = Branded<'PhoneRunId'>
/** Identifies one accepted Phone action. */
export type PhoneActionId = Branded<'PhoneActionId'>

/**
 * Brand a provider device identifier.
 * @param value - Provider-owned serial or transport identifier.
 * @returns The unchanged branded identifier.
 */
export function PhoneDeviceId(value: string): PhoneDeviceId {
  return value as PhoneDeviceId
}

/**
 * Brand an observation identifier.
 * @param value - Runtime-minted identifier.
 * @returns The unchanged branded identifier.
 */
export function PhoneObservationId(value: string): PhoneObservationId {
  return value as PhoneObservationId
}

/**
 * Brand a Phone run identifier.
 * @param value - Runtime-minted identifier.
 * @returns The unchanged branded identifier.
 */
export function PhoneRunId(value: string): PhoneRunId {
  return value as PhoneRunId
}

/**
 * Brand a Phone action identifier.
 * @param value - Runtime-minted identifier.
 * @returns The unchanged branded identifier.
 */
export function PhoneActionId(value: string): PhoneActionId {
  return value as PhoneActionId
}
