/** Phone capability Service Definitions for providers and Agent consumers. */

import { Service } from '@deepseek-ai/cordis'
import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type {
  PhoneAction,
  PhoneDevice,
  PhoneDeviceInfo,
  PhoneExecutorResult,
  PhoneRunView,
  PhoneScreenshot,
  ScheduledPhoneRun,
  SchedulePhoneRunRequest,
  StartPhoneRunRequest,
  PhoneRunExecution,
  PhoneToolActionResult,
  PhoneToolObservation,
  PhoneVisionObservation,
  PhoneVisionRequest,
} from './types.ts'
import type { PhoneDeviceId } from './brand.ts'

export * from './brand.ts'
export * from './error.ts'
export type * from './types.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    phone: PhoneDeviceRegistry
    phoneRuns: PhoneRunService
    phoneVision: PhoneVisionProvider
  }
}

/** Abstract Android device discovery and handle provider registered as `ctx.phone`. */
export abstract class PhoneDeviceRegistry extends Service {
  /** Register the provider on the Phone service key. */
  constructor(ctx: Context) {
    super(ctx, 'phone')
  }

  /**
   * Discover every ADB-visible device, including unusable states.
   * @param signal - Cooperative cancellation.
   * @returns Current device records.
   */
  abstract list(signal?: AbortSignal): Promise<readonly PhoneDeviceInfo[]>

  /**
   * Ask the provider to connect one wireless ADB address.
   * @param address - Host and port accepted by the provider.
   * @param signal - Cooperative cancellation.
   * @returns The connected device record.
   */
  abstract connect(address: string, signal?: AbortSignal): Promise<PhoneDeviceInfo>

  /**
   * Open a live handle for one usable device.
   * @param id - Concrete provider device identity.
   * @param signal - Cooperative cancellation.
   * @returns Device-bound action and observation handle.
   */
  abstract open(id: PhoneDeviceId, signal?: AbortSignal): Promise<PhoneDevice>
}

/** Abstract active-run service consumed by scoped Phone tools and Remote adapters. */
export abstract class PhoneRunService extends Service {
  /** Register the active-run provider on `ctx.phoneRuns`. */
  constructor(ctx: Context) {
    super(ctx, 'phoneRuns')
  }

  /**
   * Capture one model-visible observation for the exact owning Agent.
   * @param agent - Owning live Agent.
   * @param signal - Cooperative cancellation.
   * @returns Compact observation output.
   */
  abstract observe(agent: Agent, signal: AbortSignal): Promise<PhoneToolObservation>

  /**
   * Execute and verify exactly one action for the exact owning Agent.
   * @param agent - Owning live Agent.
   * @param action - Strict action selected by the model.
   * @param execution - Tool cancellation and terminal-turn surface.
   * @returns Verified result and next observation.
   */
  abstract act(agent: Agent, action: PhoneAction, execution: PhoneRunExecution): Promise<PhoneToolActionResult>

  /**
   * List devices available for selection in a Phone client.
   * @param signal - Cooperative cancellation.
   * @returns Current provider device records.
   */
  abstract listDevices(signal?: AbortSignal): Promise<readonly PhoneDeviceInfo[]>
  /**
   * Connect one wireless device through the active provider.
   * @param address - Provider-specific validated network address.
   * @param signal - Cooperative cancellation.
   * @returns Connected device record.
   */
  abstract connect(address: string, signal?: AbortSignal): Promise<PhoneDeviceInfo>
  /**
   * Start one run for an idle Agent.
   * @param agent - Agent that owns the run and model decisions.
   * @param request - Selected device and natural-language task.
   * @param signal - Cooperative startup cancellation.
   * @returns Initial run view.
   */
  abstract start(agent: Agent, request: StartPhoneRunRequest, signal?: AbortSignal): Promise<PhoneRunView>
  /**
   * Accept a run requested from chat while the Agent is still answering; it starts once that turn ends.
   * @param agent - Agent whose current turn requested the run.
   * @param request - Task plus an optional device, resolved and validated now.
   * @param signal - Cooperative cancellation for validation.
   * @returns The accepted device and task.
   */
  abstract scheduleStart(agent: Agent, request: SchedulePhoneRunRequest, signal?: AbortSignal): Promise<ScheduledPhoneRun>
  /**
   * Run a task on a fresh child-session executor Agent and wait for its terminal state.
   * Aborting `signal` stops the executor's run without involving the requesting Agent's model.
   * @param parent - Chat Agent whose turn requested the task.
   * @param request - Task plus an optional device.
   * @param signal - The requesting tool call's cancellation.
   * @returns The executor run's structured outcome.
   */
  abstract runInExecutor(parent: Agent, request: SchedulePhoneRunRequest, signal: AbortSignal): Promise<PhoneExecutorResult>
  /**
   * Return the current run view for an Agent.
   * @param agent - Potential run owner.
   * @returns Current view or undefined when no run is active.
   */
  abstract getView(agent: Agent): PhoneRunView | undefined
  /**
   * Pause after the current action and Agent activity settle.
   * @param agent - Exact run owner.
   * @returns Paused run view.
   */
  abstract pause(agent: Agent): Promise<PhoneRunView>
  /**
   * Resume one paused run with a fresh observation.
   * @param agent - Exact run owner.
   * @returns Running view after the fresh observation.
   */
  abstract resume(agent: Agent): Promise<PhoneRunView>
  /**
   * Stop one run and await quiescence.
   * @param agent - Exact run owner.
   * @returns Terminal stopped view.
   */
  abstract stop(agent: Agent): Promise<PhoneRunView>
  /**
   * Capture a GUI screenshot from the run device or selected idle device.
   * @param agent - Agent that owns or requests the selected device.
   * @param deviceId - Idle device when the Agent has no active run.
   * @param signal - Cooperative cancellation.
   * @returns Fresh bounded PNG screenshot.
   */
  abstract getScreenshot(agent: Agent, deviceId?: PhoneDeviceId, signal?: AbortSignal): Promise<PhoneScreenshot>
}

/** Optional screenshot-analysis provider registered as `ctx.phoneVision`. */
export abstract class PhoneVisionProvider extends Service {
  /** Register the provider on the optional visual-analysis service key. */
  constructor(ctx: Context) {
    super(ctx, 'phoneVision')
  }

  /**
   * Analyze a screenshot without executing device actions.
   * @param request - Screenshot bytes, current task, and cancellation.
   * @returns JSON-safe visual facts.
   */
  abstract analyze(request: PhoneVisionRequest): Promise<PhoneVisionObservation>
}
