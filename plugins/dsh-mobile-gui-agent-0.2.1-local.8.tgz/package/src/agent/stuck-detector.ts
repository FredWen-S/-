/** Bounded Phone action/state cycle detection. */

import type { PhoneAction, PhoneStuckStatus } from '../core/index.ts'

/** One history item retained by the deterministic stuck detector. */
export interface StuckRecord {
  /** Executed or rejected action. */
  readonly action: PhoneAction
  /** Pre-action combined state signature. */
  readonly before: string
  /** Post-action combined state signature. */
  readonly after: string
  /** Whether verification succeeded. */
  readonly success: boolean
  /** Structured error code when execution failed before verification. */
  readonly errorCode?: string
}

/** Recent-history detector for repeated actions, unchanged failures, cycles, and device errors. */
export class PhoneStuckDetector {
  private readonly history: StuckRecord[] = []

  /**
   * Record one result and diagnose the bounded recent suffix.
   * @param record - Canonical action and before/after facts.
   * @returns Stuck status and a deterministic recovery category.
   */
  record(record: StuckRecord): PhoneStuckStatus {
    this.history.push(record)
    if (this.history.length > 12) this.history.shift()
    const recent = this.history.slice(-3)
    if (recent.length === 3 && recent.every(item =>
      normalizeAction(item.action) === normalizeAction(record.action)
      && item.before === item.after
      && item.before === record.before)) {
      return { stuck: true, reason: 'repeated-action', recovery: 'choose-another-element' }
    }
    if (recent.length === 3 && recent.every(item => !item.success && item.before === item.after)) {
      return { stuck: true, reason: 'unchanged-failures', recovery: 'observe' }
    }
    const states = this.history.slice(-4).map(item => item.after)
    if (states.length === 4 && states[0] === states[2] && states[1] === states[3] && states[0] !== states[1]) {
      return { stuck: true, reason: 'state-cycle', recovery: 'back' }
    }
    const stale = recent.filter(item => item.errorCode === 'PHONE_STALE_OBSERVATION')
    if (stale.length === 3) return { stuck: true, reason: 'stale-observation', recovery: 'observe' }
    const deviceErrors = recent.filter(item => item.errorCode?.startsWith('PHONE_DEVICE_') === true || item.errorCode === 'PHONE_ADB_FAILED')
    if (deviceErrors.length === 3) return { stuck: true, reason: 'device-errors', recovery: 'wait' }
    return { stuck: false }
  }
}

/** Stable action normalization independent from object property insertion order. */
function normalizeAction(action: PhoneAction): string {
  switch (action.type) {
    case 'tap_element': return `${action.type}:${action.observationId}:${action.elementId}`
    case 'tap': return `${action.type}:${action.x}:${action.y}`
    case 'long_press': return `${action.type}:${action.x}:${action.y}:${action.durationMs ?? ''}`
    case 'swipe': return `${action.type}:${action.x1}:${action.y1}:${action.x2}:${action.y2}:${action.durationMs ?? ''}`
    case 'input_text': return `${action.type}:${action.text}`
    case 'replace_text': return `${action.type}:${action.text}`
    case 'setup_unicode_input': return action.type
    case 'press_key': return `${action.type}:${action.key}`
    case 'open_app': return `${action.type}:${action.packageName}`
    case 'wait': return `${action.type}:${action.ms}`
    case 'finish': return `${action.type}:${String(action.success)}:${action.message}`
    case 'back':
    case 'home': return action.type
  }
}
