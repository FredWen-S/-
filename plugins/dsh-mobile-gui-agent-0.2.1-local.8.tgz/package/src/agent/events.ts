/** Live Cordis events emitted by Phone Agent lifecycle and device operations. */

import type { Agent } from '@deepseek-ai/dsh-agent'
import type {
  PhoneAction,
  PhoneActionId,
  PhoneDeviceInfo,
  PhoneObservation,
  PhoneRunStep,
  PhoneRunView,
} from '../core/index.ts'

declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * An ADB device became available through discovery or connect.
     * @param device - Current device record.
     * @mode emit
     */
    'phone/connected'(device: PhoneDeviceInfo): void
    /**
     * A previously selected device is no longer usable.
     * @param device - Last known device record.
     * @mode emit
     */
    'phone/disconnected'(device: PhoneDeviceInfo): void
    /**
     * A run acquired its Agent and device.
     * @param payload - Owning Agent and run view.
     * @mode emit
     */
    'phone/agent/started'(payload: { readonly agent: Agent; readonly run: PhoneRunView }): void
    /**
     * A run reached a terminal stopped state.
     * @param payload - Owning Agent and run view.
     * @mode emit
     */
    'phone/agent/stopped'(payload: { readonly agent: Agent; readonly run: PhoneRunView }): void
    /**
     * A fresh Phone observation was published.
     * @param payload - Owning Agent, run, and observation.
     * @mode emit
     */
    'phone/observation'(payload: { readonly agent: Agent; readonly run: PhoneRunView; readonly observation: PhoneObservation }): void
    /**
     * A Phone action entered execution.
     * @param payload - Owning Agent, run, action id, and action.
     * @mode emit
     */
    'phone/action/started'(payload: { readonly agent: Agent; readonly run: PhoneRunView; readonly actionId: PhoneActionId; readonly action: PhoneAction }): void
    /**
     * A Phone action settled with verified success.
     * @param payload - Owning Agent, run, and step.
     * @mode emit
     */
    'phone/action/completed'(payload: { readonly agent: Agent; readonly run: PhoneRunView; readonly step: PhoneRunStep }): void
    /**
     * A Phone action settled with failure or rejection.
     * @param payload - Owning Agent, run, and step.
     * @mode emit
     */
    'phone/action/failed'(payload: { readonly agent: Agent; readonly run: PhoneRunView; readonly step: PhoneRunStep }): void
    /**
     * A consequential Phone action requires the existing approval flow.
     * @param payload - Owning Agent, run, action, reason, and impact.
     * @mode emit
     */
    'phone/approval/required'(payload: { readonly agent: Agent; readonly run: PhoneRunView; readonly action: PhoneAction; readonly reason: string; readonly impact: string }): void
    /**
     * A Phone task completed successfully.
     * @param payload - Owning Agent and terminal run.
     * @mode emit
     */
    'phone/task/completed'(payload: { readonly agent: Agent; readonly run: PhoneRunView }): void
    /**
     * A Phone task failed or stopped.
     * @param payload - Owning Agent and terminal run.
     * @mode emit
     */
    'phone/task/failed'(payload: { readonly agent: Agent; readonly run: PhoneRunView }): void
  }
}
