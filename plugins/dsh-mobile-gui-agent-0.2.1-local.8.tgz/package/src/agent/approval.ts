/** Consequential Phone action classification and Harness approval. */

import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { PhoneError } from '../core/index.ts'
import type { PhoneAction, PhoneObservation, PhoneUIElement } from '../core/index.ts'
import type {} from '@deepseek-ai/dsh-user-approval'

/** Human-facing reason and impact for one consequential action. */
export interface PhoneApprovalRequest {
  /** Why runtime policy classified the action. */
  readonly reason: string
  /** External or destructive effect that can occur. */
  readonly impact: string
  /** Semantic target when one was resolved. */
  readonly target?: PhoneUIElement
}

const CONSEQUENTIAL: readonly { readonly pattern: RegExp; readonly reason: string; readonly impact: string }[] = [
  { pattern: /(?:发送|send|submit|post|发布|发帖|reply|回复)/iu, reason: 'This control can publish or send content.', impact: 'A message, email, reply, or post may become visible to another person.' },
  { pattern: /(?:删除|delete|remove|erase|卸载|uninstall)/iu, reason: 'This control can delete data or software.', impact: 'Data or an installed app may be removed.' },
  { pattern: /(?:付款|支付|pay|purchase|购买|buy|下单|place order|transfer|转账)/iu, reason: 'This control can commit a financial transaction.', impact: 'Money may be transferred or an order may be placed.' },
  { pattern: /(?:修改密码|change password|账号安全|account security|security settings)/iu, reason: 'This control can change account security.', impact: 'Credentials or account recovery settings may change.' },
  { pattern: /(?:拨打|call|dial)/iu, reason: 'This control can place a phone call.', impact: 'The device may call another person or service.' },
  { pattern: /(?:安装|install|允许安装|package installer)/iu, reason: 'This control can install software.', impact: 'An APK or application may be installed.' },
]

/**
 * Classify a semantic or coordinate action against visible UI text.
 * @param action - Proposed strict Phone action.
 * @param observation - Fresh pre-action state.
 * @returns Approval request for consequential effects, otherwise undefined.
 */
export function classifyPhoneAction(
  action: PhoneAction,
  observation: PhoneObservation,
): PhoneApprovalRequest | undefined {
  if (action.type === 'setup_unicode_input') {
    return {
      reason: 'The Unicode input helper must be explicitly authorized before device settings change.',
      impact: 'A configured APK may be installed, and the current Android input method will be switched temporarily and restored.',
    }
  }
  const target = targetFor(action, observation)
  const label = target === undefined
    ? action.type === 'press_key' && action.key === 'enter'
      ? observation.elements.map(elementLabel).join(' ')
      : ''
    : elementLabel(target)
  for (const category of CONSEQUENTIAL) {
    if (!category.pattern.test(label)) continue
    return {
      reason: category.reason,
      impact: category.impact,
      ...(target === undefined ? {} : { target }),
    }
  }
  return undefined
}

/**
 * Request one-shot approval through the existing Harness service.
 * @param ctx - Context that may carry the optional approval service.
 * @param agent - Agent whose open tool turn owns the audit.
 * @param request - Classified reason and impact.
 * @param signal - Cooperative cancellation.
 */
export async function requirePhoneApproval(
  ctx: Context,
  agent: Agent,
  request: PhoneApprovalRequest,
  signal: AbortSignal,
): Promise<void> {
  const approval = ctx.get('approval')
  if (approval === undefined) {
    throw new PhoneError('PHONE_APPROVAL_DENIED', 'consequential Phone action requires an approval provider')
  }
  const outcome = await approval.request({
    agent,
    toolName: 'phone_act',
    reason: `${request.reason} Impact: ${request.impact}`,
    signal,
  })
  if (outcome !== 'allowed-once') {
    throw new PhoneError('PHONE_APPROVAL_DENIED', `Phone action approval was ${outcome}`)
  }
}

/** Resolve the smallest semantic element containing a coordinate or exact element id. */
function targetFor(action: PhoneAction, observation: PhoneObservation): PhoneUIElement | undefined {
  if (action.type === 'tap_element') return observation.elements.find(element => element.id === action.elementId)
  if (action.type !== 'tap' && action.type !== 'long_press') return undefined
  return observation.elements
    .filter(element => action.x >= element.bounds[0] && action.x < element.bounds[2]
      && action.y >= element.bounds[1] && action.y < element.bounds[3])
    .sort((left, right) => area(left) - area(right))[0]
}

/** Semantic text inspected by consequential-action policy. */
function elementLabel(element: PhoneUIElement): string {
  return [element.text, element.contentDescription, element.resourceId, element.className].filter(Boolean).join(' ')
}

/** Pixel area used to select the nearest coordinate target. */
function area(element: PhoneUIElement): number {
  return (element.bounds[2] - element.bounds[0]) * (element.bounds[3] - element.bounds[1])
}
