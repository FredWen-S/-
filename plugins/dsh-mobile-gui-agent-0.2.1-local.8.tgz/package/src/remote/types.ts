/** Client-safe Phone Agent Remote payloads. */

/** Bounded PNG response safe for Typert JSON transport. */
export interface PhoneScreenshotResponse {
  /** Base64-encoded PNG bytes without a data-URL prefix. */
  readonly data: string
  /** Intrinsic width. */
  readonly width: number
  /** Intrinsic height. */
  readonly height: number
  /** Capture time. */
  readonly timestamp: number
}
