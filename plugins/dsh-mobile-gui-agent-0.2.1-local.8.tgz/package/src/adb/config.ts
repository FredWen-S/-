/** ADB provider configuration and explicit default resolution. */

import { isAbsolute } from 'node:path'
import type { Config } from './index.ts'

/** Complete validated ADB provider configuration. */
export interface ResolvedConfig {
  /** Resolved executable setting. */
  readonly adbPath: string
  /** User-reviewed helper APK eligible for an approved install. */
  readonly unicodeImeApkPath?: string
  /** Resolved command timeout. */
  readonly commandTimeoutMs: number
  /** Resolved process grace. */
  readonly processGraceMs: number
  /** Resolved screenshot byte cap. */
  readonly screenshotMaxBytes: number
  /** Resolved hierarchy byte cap. */
  readonly hierarchyMaxBytes: number
  /** Resolved diagnostic byte cap. */
  readonly diagnosticMaxBytes: number
  /** Resolved hierarchy count cap. */
  readonly hierarchyMaxElements: number
  /** Resolved hierarchy serialization cap. */
  readonly hierarchyMaxSerializedBytes: number
  /** Resolved UIAutomator attempt count. */
  readonly hierarchyAttempts: number
  /** Resolved delay between UIAutomator attempts. */
  readonly hierarchyRetryDelayMs: number
  /** Resolved stable-screen poll interval. */
  readonly stablePollMs: number
  /** Resolved stable comparison count. */
  readonly stableSamples: number
  /** Resolved stable-screen timeout. */
  readonly stableTimeoutMs: number
  /** Resolved normalized stable threshold. */
  readonly stableDifferenceThreshold: number
}

/**
 * Validate and materialize every ADB provider default.
 * @param config - Loader-parsed partial configuration.
 * @returns Complete configuration.
 */
export function resolveConfig(config: Config): ResolvedConfig {
  const resolved: ResolvedConfig = {
    adbPath: config.adbPath ?? 'adb',
    ...(config.unicodeImeApkPath === undefined ? {} : { unicodeImeApkPath: config.unicodeImeApkPath }),
    commandTimeoutMs: config.commandTimeoutMs ?? 10_000,
    processGraceMs: config.processGraceMs ?? 1_000,
    screenshotMaxBytes: config.screenshotMaxBytes ?? 16 * 1024 * 1024,
    hierarchyMaxBytes: config.hierarchyMaxBytes ?? 4 * 1024 * 1024,
    diagnosticMaxBytes: config.diagnosticMaxBytes ?? 64 * 1024,
    hierarchyMaxElements: config.hierarchyMaxElements ?? 400,
    hierarchyMaxSerializedBytes: config.hierarchyMaxSerializedBytes ?? 64 * 1024,
    hierarchyAttempts: config.hierarchyAttempts ?? 3,
    hierarchyRetryDelayMs: config.hierarchyRetryDelayMs ?? 300,
    stablePollMs: config.stablePollMs ?? 300,
    stableSamples: config.stableSamples ?? 3,
    stableTimeoutMs: config.stableTimeoutMs ?? 5_000,
    stableDifferenceThreshold: config.stableDifferenceThreshold ?? 0.01,
  }
  if (resolved.adbPath.trim().length === 0) throw new Error('phone-adb: adbPath must be non-empty')
  if (resolved.unicodeImeApkPath !== undefined) {
    if (resolved.unicodeImeApkPath.trim().length === 0) {
      throw new Error('phone-adb: unicodeImeApkPath must be non-empty when configured')
    }
    if (!isAbsolute(resolved.unicodeImeApkPath)) {
      throw new Error('phone-adb: unicodeImeApkPath must be an absolute path')
    }
  }
  const positiveIntegers = [
    'commandTimeoutMs',
    'processGraceMs',
    'screenshotMaxBytes',
    'hierarchyMaxBytes',
    'diagnosticMaxBytes',
    'hierarchyMaxElements',
    'hierarchyMaxSerializedBytes',
    'hierarchyAttempts',
    'hierarchyRetryDelayMs',
    'stablePollMs',
    'stableSamples',
    'stableTimeoutMs',
  ] as const
  for (const key of positiveIntegers) {
    const value = resolved[key]
    if (!Number.isSafeInteger(value) || value < 1) {
      throw new Error(`phone-adb: ${key} must be a positive safe integer`)
    }
  }
  if (!Number.isFinite(resolved.stableDifferenceThreshold)
    || resolved.stableDifferenceThreshold < 0
    || resolved.stableDifferenceThreshold > 1) {
    throw new Error('phone-adb: stableDifferenceThreshold must be between 0 and 1')
  }
  return resolved
}
