/** ADB device-list parsing and wireless-address validation. */

import { PhoneDeviceId } from '../core/index.ts'
import type { PhoneDeviceInfo, PhoneDeviceStatus } from '../core/index.ts'

/**
 * Parse `adb devices -l` without dropping offline or unauthorized records.
 * @param output - Complete bounded command stdout.
 * @returns Device records in ADB order.
 */
export function parseAdbDevices(output: string): readonly PhoneDeviceInfo[] {
  const records: PhoneDeviceInfo[] = []
  for (const rawLine of output.split(/\r?\n/u).slice(1)) {
    const line = rawLine.trim()
    if (line.length === 0 || line.startsWith('*')) continue
    const [serial, rawStatus, ...facts] = line.split(/\s+/u)
    if (serial === undefined || rawStatus === undefined) continue
    const status = deviceStatus(rawStatus)
    if (status === undefined) continue
    const fields = Object.fromEntries(facts.flatMap((fact) => {
      const separator = fact.indexOf(':')
      return separator < 1 ? [] : [[fact.slice(0, separator), fact.slice(separator + 1)]]
    }))
    records.push({
      id: PhoneDeviceId(serial),
      status,
      ...(fields.model === undefined ? {} : { model: fields.model }),
      ...(fields.product === undefined ? {} : { product: fields.product }),
      ...(fields.transport_id === undefined ? {} : { transportId: fields.transport_id }),
    })
  }
  return records
}

/**
 * Validate one direct-argv wireless ADB endpoint.
 * @param address - Hostname, IPv4, or bracketed IPv6 plus port.
 * @returns Trimmed validated address.
 */
export function parseWirelessAddress(address: string): string {
  const value = address.trim()
  if (!/^(?:[A-Za-z0-9._-]+|\[[0-9A-Fa-f:]+\]):[1-9][0-9]{0,4}$/u.test(value)) {
    throw new Error('phone-adb: wireless address must be HOST:PORT')
  }
  const port = Number(value.slice(value.lastIndexOf(':') + 1))
  if (port > 65_535) throw new Error('phone-adb: wireless address port must be at most 65535')
  return value
}

/** Map only ADB states represented by the public Phone vocabulary. */
function deviceStatus(value: string): PhoneDeviceStatus | undefined {
  if (value === 'device' || value === 'offline' || value === 'unauthorized') return value
  return undefined
}
