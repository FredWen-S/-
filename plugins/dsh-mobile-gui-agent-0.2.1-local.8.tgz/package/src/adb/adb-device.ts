/** Device-bound ADB Phone implementation. */

import { randomUUID } from 'node:crypto'
import { setTimeout as waitTimer } from 'node:timers/promises'
import {
  PhoneError,
  PhoneObservationId,
  throwIfPhoneAborted,
} from '../core/index.ts'
import type {
  PhoneCapture,
  PhoneDevice,
  PhoneDeviceId,
  PhoneHierarchy,
  PhoneKey,
  PhoneObservation,
  PhoneScreenshot,
  PhoneShellRequest,
  StableScreenOptions,
  StableScreenResult,
} from '../core/index.ts'
import type { ResolvedConfig } from './config.ts'
import type { AdbClient } from './adb-client.ts'
import { extractHierarchyXml, parseUiHierarchy } from './hierarchy.ts'
import { inferForegroundPackage, parseForegroundState, parseKeyboardVisible, parseLocked } from './foreground.ts'
import { decodeScreenshot, screenshotDifference } from './screenshot.ts'
import {
  ADB_KEYBOARD,
  adbKeyboardAvailability,
  isAdbKeyboardComponent,
  selectedInputMethod,
} from './unicode-ime.ts'
import type { AdbKeyboardAvailability } from './unicode-ime.ts'

const KEY_CODES: Readonly<Record<PhoneKey, string>> = {
  enter: 'KEYCODE_ENTER',
  delete: 'KEYCODE_DEL',
  tab: 'KEYCODE_TAB',
  escape: 'KEYCODE_ESCAPE',
  volume_up: 'KEYCODE_VOLUME_UP',
  volume_down: 'KEYCODE_VOLUME_DOWN',
  power: 'KEYCODE_POWER',
}

/** UIAutomator's report for a screen that never stops redrawing (live counters, animations). */
const IDLE_STATE_FAILURE = /could not get idle state/iu

/** Signature shared by observations whose hierarchy was unavailable, so it never signals a UI change. */
const UNAVAILABLE_HIERARCHY_SIGNATURE = 'hierarchy-unavailable'

/**
 * UIAutomator cannot dump this screen at all; retrying or switching dump paths waits for the same idle state.
 * A dump outliving `commandTimeoutMs` is the same failure seen before UIAutomator gives up (~12s on emulators).
 */
class UiAutomatorIdleError extends PhoneError {
  constructor(message = 'UIAutomator could not get an idle state because the screen keeps redrawing', cause?: unknown) {
    super('PHONE_HIERARCHY_INVALID', message, cause)
  }
}

/** Android device handle whose every operation is routed through one serial. */
export class AdbPhoneDevice implements PhoneDevice {
  /**
   * Bind a provider client to one usable device.
   * @param id - Concrete ADB serial.
   * @param client - Managed direct-argv client.
   * @param config - Resolved provider limits.
   */
  constructor(
    readonly id: PhoneDeviceId,
    private readonly client: AdbClient,
    private readonly config: ResolvedConfig,
  ) {}

  /** @inheritdoc */
  async screenshot(signal?: AbortSignal): Promise<PhoneScreenshot> {
    const data = await this.client.binary(['-s', this.id, 'exec-out', 'screencap', '-p'], this.config.screenshotMaxBytes, signal)
    return decodeScreenshot(data, Date.now())
  }

  /** @inheritdoc */
  async getUIHierarchy(signal?: AbortSignal): Promise<PhoneHierarchy> {
    const screenshot = await this.screenshot(signal)
    return this.captureHierarchy(screenshot.width, screenshot.height, signal)
  }

  /** @inheritdoc */
  async getState(signal?: AbortSignal): Promise<PhoneCapture> {
    const screenshot = await this.screenshot(signal)
    const [hierarchy, windowState, activityState, inputMethod, policy] = await Promise.all([
      this.captureHierarchyOrUnavailable(screenshot.width, screenshot.height, signal),
      this.diagnostic(['dumpsys', 'window', 'windows'], signal),
      this.diagnostic(['dumpsys', 'activity', 'activities'], signal),
      this.diagnostic(['dumpsys', 'input_method'], signal),
      this.diagnostic(['dumpsys', 'window', 'policy'], signal),
    ])
    const foreground = parseForegroundState(`${windowState}\n${activityState}`)
    const foregroundPackage = foreground.packageName ?? inferForegroundPackage(hierarchy.elements)
    const keyboardVisible = parseKeyboardVisible(`${inputMethod}\n${windowState}`)
    const locked = parseLocked(policy)
    const observation: PhoneObservation = {
      id: PhoneObservationId(randomUUID()),
      deviceId: this.id,
      timestamp: screenshot.timestamp,
      width: screenshot.width,
      height: screenshot.height,
      orientation: screenshot.width === screenshot.height
        ? 'square'
        : screenshot.width > screenshot.height ? 'landscape' : 'portrait',
      screenshotDigest: screenshot.digest,
      screenshotSignature: screenshot.comparisonSignature,
      ...(foregroundPackage === undefined ? {} : { foregroundPackage }),
      ...(foreground.activity === undefined ? {} : { activity: foreground.activity }),
      ...(keyboardVisible === undefined ? {} : { keyboardVisible }),
      ...(locked === undefined ? {} : { locked }),
      elements: hierarchy.elements,
      uiSignature: hierarchy.signature,
      hierarchyTruncated: hierarchy.truncated,
      ...(hierarchy.unavailable === undefined ? {} : { hierarchyUnavailable: hierarchy.unavailable }),
    }
    return { observation, screenshot }
  }

  /** @inheritdoc */
  async tap(x: number, y: number, signal?: AbortSignal): Promise<void> {
    await this.assertCoordinates([[x, y]], signal)
    await this.runShell(['input', 'tap', String(x), String(y)], signal)
  }

  /** @inheritdoc */
  async longPress(x: number, y: number, durationMs: number, signal?: AbortSignal): Promise<void> {
    await this.assertCoordinates([[x, y]], signal)
    await this.runShell(['input', 'swipe', String(x), String(y), String(x), String(y), String(durationMs)], signal)
  }

  /** @inheritdoc */
  async swipe(x1: number, y1: number, x2: number, y2: number, durationMs: number, signal?: AbortSignal): Promise<void> {
    await this.assertCoordinates([[x1, y1], [x2, y2]], signal)
    await this.runShell(['input', 'swipe', String(x1), String(y1), String(x2), String(y2), String(durationMs)], signal)
  }

  /** @inheritdoc */
  async inputText(text: string, signal?: AbortSignal): Promise<void> {
    if (/[^\u0020-\u007e]/u.test(text)) {
      await this.withAdbKeyboard(signal, async () => {
        await this.broadcastAdbKeyboard(ADB_KEYBOARD.inputAction, text, signal)
      })
      return
    }
    await this.runShell(['input', 'text', escapeInputText(text)], signal)
  }

  /** @inheritdoc */
  async replaceText(text: string, signal?: AbortSignal): Promise<void> {
    if (/[^\u0020-\u007e]/u.test(text)) {
      await this.withAdbKeyboard(signal, async () => {
        await this.broadcastAdbKeyboard(ADB_KEYBOARD.clearAction, undefined, signal)
        await this.broadcastAdbKeyboard(ADB_KEYBOARD.inputAction, text, signal)
      })
      return
    }
    await this.runShell(['input', 'keycombination', 'KEYCODE_CTRL_LEFT', 'KEYCODE_A'], signal)
    await this.runShell(['input', 'keyevent', 'KEYCODE_DEL'], signal)
    if (text.length > 0) await this.runShell(['input', 'text', escapeInputText(text)], signal)
  }

  /** @inheritdoc */
  async setupUnicodeInput(signal?: AbortSignal): Promise<void> {
    let state = await this.adbKeyboardState(signal)
    if (state.availability !== 'ready' && selectedInputMethod(state.selected) === undefined) {
      throw new PhoneError(
        'PHONE_UNICODE_INPUT_UNSUPPORTED',
        'Unicode input helper cannot be set up safely because the current input method could not be identified for restoration',
      )
    }
    if (state.availability === 'not-installed') {
      const apkPath = this.config.unicodeImeApkPath
      if (apkPath === undefined) {
        throw new PhoneError(
          'PHONE_UNICODE_INPUT_UNSUPPORTED',
          'Unicode input helper is not installed; configure adb.unicodeImeApkPath with an absolute path to a reviewed ADB Keyboard APK, restart the plugin, then run setup_unicode_input again',
        )
      }
      await this.client.text(
        ['-s', this.id, 'install', '-r', apkPath],
        this.config.diagnosticMaxBytes,
        signal,
      )
      state = await this.adbKeyboardState(signal)
      if (state.availability === 'not-installed') {
        throw new PhoneError(
          'PHONE_ADB_FAILED',
          `ADB reported a successful install but ${ADB_KEYBOARD.component} is still unavailable`,
        )
      }
    }
    await this.withAdbKeyboard(signal, async () => {}, state)
  }

  /** @inheritdoc */
  async pressKey(key: PhoneKey, signal?: AbortSignal): Promise<void> {
    await this.runShell(['input', 'keyevent', KEY_CODES[key]], signal)
  }

  /** @inheritdoc */
  async back(signal?: AbortSignal): Promise<void> {
    await this.runShell(['input', 'keyevent', 'KEYCODE_BACK'], signal)
  }

  /** @inheritdoc */
  async home(signal?: AbortSignal): Promise<void> {
    await this.runShell(['input', 'keyevent', 'KEYCODE_HOME'], signal)
  }

  /** @inheritdoc */
  async openApp(packageName: string, signal?: AbortSignal): Promise<void> {
    const normalized = packageName.trim()
    if (!/^[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+$/u.test(normalized)) {
      throw new PhoneError('PHONE_PACKAGE_NOT_LAUNCHABLE', `invalid Android package name ${JSON.stringify(packageName)}`)
    }
    const resolution = await this.runShell(['cmd', 'package', 'resolve-activity', '--brief', normalized], signal)
    const component = resolution.split(/\r?\n/u).map(line => line.trim()).find(line => line.includes('/'))
    if (component === undefined || !/^[A-Za-z0-9._]+\/[A-Za-z0-9.$_]+$/u.test(component)) {
      throw new PhoneError('PHONE_PACKAGE_NOT_LAUNCHABLE', `Android package ${JSON.stringify(normalized)} has no launcher activity`)
    }
    await this.runShell(['am', 'start', '-n', component], signal)
  }

  /** @inheritdoc */
  async shell(request: PhoneShellRequest, signal?: AbortSignal): Promise<string> {
    if (!Number.isSafeInteger(request.maxOutputBytes) || request.maxOutputBytes < 1
      || request.maxOutputBytes > this.config.hierarchyMaxBytes) {
      throw new PhoneError('PHONE_ACTION_REJECTED', 'classified Phone shell output cap is invalid')
    }
    return this.runShell(request.argv, signal, request.maxOutputBytes)
  }

  /** @inheritdoc */
  async wait(ms: number, signal?: AbortSignal): Promise<void> {
    await waitTimer(ms, undefined, { signal })
  }

  /** @inheritdoc */
  async waitForStableScreen(options: StableScreenOptions, signal?: AbortSignal): Promise<StableScreenResult> {
    const deadline = Date.now() + options.timeoutMs
    let previous = await this.screenshot(signal)
    let stable = 0
    let samples = 1
    let difference = 1
    while (Date.now() < deadline) {
      await this.wait(Math.min(options.pollMs, Math.max(1, deadline - Date.now())), signal)
      const current = await this.screenshot(signal)
      samples++
      difference = screenshotDifference(previous.comparisonSignature, current.comparisonSignature)
      stable = difference <= options.differenceThreshold ? stable + 1 : 0
      previous = current
      if (stable >= options.stableSamples) {
        return { screenshot: current, stable: true, timedOut: false, samples, difference }
      }
    }
    return { screenshot: previous, stable: false, timedOut: true, samples, difference }
  }

  private async captureHierarchy(width: number, height: number, signal?: AbortSignal): Promise<PhoneHierarchy> {
    const xml = await this.dumpHierarchy(signal)
    return parseUiHierarchy(xml, {
      width,
      height,
      maxElements: this.config.hierarchyMaxElements,
      maxSerializedBytes: this.config.hierarchyMaxSerializedBytes,
    })
  }

  /** Keep screenshot and foreground facts usable when only the hierarchy cannot be read. */
  private async captureHierarchyOrUnavailable(
    width: number,
    height: number,
    signal?: AbortSignal,
  ): Promise<PhoneHierarchy & { readonly unavailable?: string }> {
    try {
      return await this.captureHierarchy(width, height, signal)
    } catch (error: unknown) {
      throwIfPhoneAborted(signal, 'UI hierarchy capture was cancelled')
      if (!(error instanceof PhoneError) || error.code !== 'PHONE_HIERARCHY_INVALID') throw error
      return { elements: [], signature: UNAVAILABLE_HIERARCHY_SIGNATURE, truncated: false, unavailable: error.message }
    }
  }

  private async dumpHierarchy(signal?: AbortSignal): Promise<string> {
    let cause: unknown
    for (let attempt = 1; attempt <= this.config.hierarchyAttempts; attempt++) {
      try {
        return await this.dumpHierarchyOnce(signal)
      } catch (error: unknown) {
        throwIfPhoneAborted(signal, 'UI hierarchy capture was cancelled')
        if (error instanceof UiAutomatorIdleError) throw error
        cause = error
        if (attempt < this.config.hierarchyAttempts) {
          await this.wait(this.config.hierarchyRetryDelayMs, signal)
        }
      }
    }
    throw new PhoneError(
      'PHONE_HIERARCHY_INVALID',
      `UIAutomator did not return XML after ${this.config.hierarchyAttempts} attempts`,
      cause,
    )
  }

  private async dumpHierarchyOnce(signal?: AbortSignal): Promise<string> {
    try {
      const direct = await this.uiAutomatorDump('/dev/tty', this.config.hierarchyMaxBytes, signal)
      return extractHierarchyXml(direct)
    } catch (error: unknown) {
      if (error instanceof UiAutomatorIdleError) throw error
      throwIfPhoneAborted(signal, 'UI hierarchy capture was cancelled')
      // The device may not support dumping to /dev/tty; fall back to a device temp file.
      const remotePath = `/data/local/tmp/dsh-phone-${randomUUID()}.xml`
      try {
        await this.uiAutomatorDump(remotePath, this.config.diagnosticMaxBytes, signal)
        const result = await this.client.text(
          ['-s', this.id, 'exec-out', 'cat', remotePath],
          this.config.hierarchyMaxBytes,
          signal,
        )
        return extractHierarchyXml(result.stdout)
      } finally {
        try {
          await this.client.text(
            ['-s', this.id, 'shell', 'rm', '-f', remotePath],
            this.config.diagnosticMaxBytes,
            signal,
          )
        } catch (_bestEffortDeviceTempCleanup) {
          // The randomized file contains only public accessibility XML and Android may already have removed it.
        }
      }
    }
  }

  /** Run one `uiautomator dump`, classifying the idle failure and never leaving a stuck dump behind. */
  private async uiAutomatorDump(target: string, maxBytes: number, signal?: AbortSignal): Promise<string> {
    let stdout: string
    try {
      ;({ stdout } = await this.client.text(['-s', this.id, 'shell', 'uiautomator', 'dump', target], maxBytes, signal))
    } catch (error: unknown) {
      if (!(error instanceof PhoneError) || error.code !== 'PHONE_ACTION_TIMEOUT') throw error
      await this.stopUiAutomator()
      throwIfPhoneAborted(signal, 'UI hierarchy capture was cancelled')
      throw new UiAutomatorIdleError(`UIAutomator did not finish within ${this.config.commandTimeoutMs}ms; the screen may keep redrawing`, error)
    }
    if (IDLE_STATE_FAILURE.test(stdout)) throw new UiAutomatorIdleError()
    return stdout
  }

  /**
   * Stop a dump that outlived its host-side ADB command.
   * Android allows one UiAutomation connection, so a leftover dump makes the next one fail.
   */
  private async stopUiAutomator(): Promise<void> {
    try {
      await this.client.text(
        ['-s', this.id, 'shell', 'pkill', '-x', 'uiautomator'],
        this.config.diagnosticMaxBytes,
        AbortSignal.timeout(this.config.commandTimeoutMs),
      )
    } catch (_bestEffortStuckDumpCleanup) {
      // pkill exits non-zero when the dump already ended; the next capture reports any real failure.
    }
  }

  private async diagnostic(argv: readonly string[], signal?: AbortSignal): Promise<string> {
    try {
      return await this.runShell(argv, signal)
    } catch (_optionalAndroidDiagnosticUnavailable) {
      return ''
    }
  }

  private async runShell(
    argv: readonly string[],
    signal?: AbortSignal,
    maxOutputBytes = this.config.diagnosticMaxBytes,
  ): Promise<string> {
    const result = await this.client.text(['-s', this.id, 'shell', ...argv], maxOutputBytes, signal)
    return result.stdout
  }

  /** Read the supported helper's install, enabled, and selection state. */
  private async adbKeyboardState(signal?: AbortSignal): Promise<{
    readonly availability: AdbKeyboardAvailability
    readonly selected: string
  }> {
    const [installed, enabled, selected] = await Promise.all([
      this.runShell(['ime', 'list', '-a', '-s'], signal),
      this.runShell(['settings', 'get', 'secure', 'enabled_input_methods'], signal),
      this.runShell(['settings', 'get', 'secure', 'default_input_method'], signal),
    ])
    return { availability: adbKeyboardAvailability(installed, enabled, selected), selected }
  }

  /** Use an installed helper temporarily, always restoring the user's selected and enabled IME state. */
  private async withAdbKeyboard(
    signal: AbortSignal | undefined,
    operation: () => Promise<void>,
    knownState?: { readonly availability: AdbKeyboardAvailability; readonly selected: string },
  ): Promise<void> {
    const state = knownState ?? await this.adbKeyboardState(signal)
    if (state.availability === 'ready') {
      await operation()
      return
    }
    if (state.availability === 'not-installed') {
      throw new PhoneError('PHONE_UNICODE_INPUT_UNSUPPORTED', adbKeyboardUnavailableMessage(state.availability))
    }
    const previous = selectedInputMethod(state.selected)
    if (previous === undefined) {
      throw new PhoneError(
        'PHONE_UNICODE_INPUT_UNSUPPORTED',
        'Unicode input helper cannot be selected safely because the current input method could not be identified for restoration',
      )
    }
    const enableTemporarily = state.availability === 'not-enabled'
    const selectTemporarily = !isAdbKeyboardComponent(previous)
    let enabled = false
    let selected = false
    try {
      if (enableTemporarily) {
        enabled = true
        await this.runShell(['ime', 'enable', ADB_KEYBOARD.component], signal)
      }
      if (selectTemporarily) {
        selected = true
        await this.runShell(['ime', 'set', ADB_KEYBOARD.component], signal)
      }
      const ready = await this.adbKeyboardState(signal)
      if (ready.availability !== 'ready') {
        throw new PhoneError('PHONE_ADB_FAILED', `ADB could not activate the Unicode input helper: ${adbKeyboardUnavailableMessage(ready.availability)}`)
      }
      await operation()
    } finally {
      const cleanupSignal = AbortSignal.timeout(this.config.commandTimeoutMs)
      try {
        if (selected) await this.runShell(['ime', 'set', previous], cleanupSignal)
      } finally {
        if (enabled) await this.runShell(['ime', 'disable', ADB_KEYBOARD.component], cleanupSignal)
      }
    }
  }

  /** Send one package-scoped ADB Keyboard broadcast with optional UTF-8 Base64 text. */
  private async broadcastAdbKeyboard(action: string, text: string | undefined, signal?: AbortSignal): Promise<void> {
    await this.runShell([
      'am',
      'broadcast',
      '-a',
      action,
      '-p',
      ADB_KEYBOARD.packageName,
      ...(text === undefined ? [] : ['--es', 'msg', Buffer.from(text, 'utf8').toString('base64')]),
    ], signal)
  }

  private async assertCoordinates(points: readonly (readonly [number, number])[], signal?: AbortSignal): Promise<void> {
    for (const [x, y] of points) {
      if (!Number.isSafeInteger(x) || !Number.isSafeInteger(y)) {
        throw new PhoneError('PHONE_COORDINATE_OUT_OF_BOUNDS', 'Phone coordinates must be safe integers')
      }
    }
    const screenshot = await this.screenshot(signal)
    for (const [x, y] of points) {
      if (x < 0 || y < 0 || x >= screenshot.width || y >= screenshot.height) {
        throw new PhoneError(
          'PHONE_COORDINATE_OUT_OF_BOUNDS',
          `coordinate (${x},${y}) is outside ${screenshot.width}x${screenshot.height}`,
        )
      }
    }
  }
}

/** Escape the argument format parsed by Android's `input text` command. */
function escapeInputText(text: string): string {
  return text.replace(/%/gu, '%25').replace(/ /gu, '%s').replace(/([\\&<>;()|'"`$])/gu, '\\$1')
}

/** Explain the exact user-owned helper prerequisite without silently mutating the device. */
function adbKeyboardUnavailableMessage(availability: Exclude<AdbKeyboardAvailability, 'ready'>): string {
  const prerequisite = availability === 'not-installed'
    ? 'not installed'
    : availability === 'not-enabled' ? 'not enabled' : 'not selected as the current input method'
  return `Unicode input is unavailable because ADB Keyboard (${ADB_KEYBOARD.component}) is ${prerequisite}`
}
