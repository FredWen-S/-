/** Pure Phone view presentation helpers. */

import type { PhoneAction, PhoneBounds, PhoneRunStep, PhoneRunView, PhoneUIElement } from '../core/client.ts'

/** Percentage rectangle displayed over the rendered screenshot. */
export interface PhoneOverlay {
  /** Horizontal start percentage. */
  readonly left: number
  /** Vertical start percentage. */
  readonly top: number
  /** Width percentage. */
  readonly width: number
  /** Height percentage. */
  readonly height: number
}

/** Keep a newer run snapshot from being overwritten by a late polling response. */
export function preferPhoneRunView(
  current: PhoneRunView | undefined,
  incoming: PhoneRunView,
): PhoneRunView {
  if (current === undefined) return incoming
  if (current.id !== incoming.id) return incoming.startedAt >= current.startedAt ? incoming : current
  if (incoming.updatedAt !== current.updatedAt) return incoming.updatedAt > current.updatedAt ? incoming : current
  if (incoming.stepCount !== current.stepCount) return incoming.stepCount > current.stepCount ? incoming : current
  return incoming.steps.length >= current.steps.length ? incoming : current
}

/**
 * Describe a strict action without exposing arbitrary JSON.
 * @param action - Accepted Phone action.
 * @returns Compact human-readable action.
 */
export function describePhoneAction(action: PhoneAction): string {
  switch (action.type) {
    case 'tap_element': return `tap element #${action.elementId}`
    case 'tap': return `tap (${action.x}, ${action.y})`
    case 'long_press': return `long press (${action.x}, ${action.y})`
    case 'swipe': return `swipe (${action.x1}, ${action.y1}) → (${action.x2}, ${action.y2})`
    case 'input_text': return `input ${JSON.stringify(action.text)}`
    case 'replace_text': return `replace text with ${JSON.stringify(action.text)}`
    case 'setup_unicode_input': return 'set up Unicode input'
    case 'press_key': return `press ${action.key}`
    case 'back': return 'back'
    case 'home': return 'home'
    case 'open_app': return `open ${action.packageName}`
    case 'wait': return `wait ${action.ms} ms`
    case 'finish': return `${action.success ? 'finish' : 'fail'}: ${action.message}`
  }
}

function boundsOverlay(bounds: PhoneBounds, screenWidth: number, screenHeight: number): PhoneOverlay | undefined {
  if (screenWidth <= 0 || screenHeight <= 0) return undefined
  const [left, top, right, bottom] = bounds
  return {
    left: left / screenWidth * 100,
    top: top / screenHeight * 100,
    width: (right - left) / screenWidth * 100,
    height: (bottom - top) / screenHeight * 100,
  }
}

/**
 * Resolve the most recent coordinate or semantic target for screenshot debug overlay.
 * @param step - Last settled step.
 * @param elements - Latest observed semantic elements.
 * @param screenWidth - Screenshot width.
 * @param screenHeight - Screenshot height.
 * @returns Percentage rectangle, or undefined for non-positional actions.
 */
export function phoneActionOverlay(
  step: PhoneRunStep | undefined,
  elements: readonly PhoneUIElement[],
  screenWidth: number,
  screenHeight: number,
): PhoneOverlay | undefined {
  if (step === undefined) return undefined
  const action = step.action
  if (action.type === 'tap_element') {
    const element = elements.find(candidate => candidate.id === action.elementId)
    return element === undefined ? undefined : boundsOverlay(element.bounds, screenWidth, screenHeight)
  }
  if (action.type === 'tap' || action.type === 'long_press') {
    const size = Math.max(20, Math.min(screenWidth, screenHeight) * 0.035)
    return boundsOverlay([
      action.x - size / 2,
      action.y - size / 2,
      action.x + size / 2,
      action.y + size / 2,
    ], screenWidth, screenHeight)
  }
  if (action.type === 'swipe') {
    return boundsOverlay([
      Math.min(action.x1, action.x2),
      Math.min(action.y1, action.y2),
      Math.max(action.x1, action.x2),
      Math.max(action.y1, action.y2),
    ], screenWidth, screenHeight)
  }
  return undefined
}
