/** Semantic execution trace projection over raw Phone tool actions. */

import type {
  PhoneAction,
  PhonePendingStep,
  PhoneRunStep,
  PhoneRunView,
  PhoneStepTarget,
  PhoneVerification,
} from '../core/client.ts'

export type AgentStepType =
  | 'goal'
  | 'action'
  | 'observation'
  | 'verification'
  | 'failure'
  | 'strategy_change'

export type AgentStepStatus = 'pending' | 'success' | 'warning' | 'error' | 'info'

export interface SemanticVerification {
  readonly summary: string
  readonly changed: boolean
  readonly uiHierarchyChanged?: boolean
  readonly screenshotChanged?: boolean
  readonly foregroundPackageChanged?: boolean
  readonly activityChanged?: boolean
}

export interface SemanticAgentStep {
  readonly id: string
  readonly index: number
  readonly type: AgentStepType
  readonly status: AgentStepStatus
  readonly title: string
  readonly description: string
  readonly goal?: string
  readonly reason?: string
  readonly actionSummary?: string
  readonly resultSummary?: string
  readonly judgment?: string
  readonly nextStep?: string
  readonly verification?: SemanticVerification
  readonly retryCount?: number
  readonly pendingPhase?: PhonePendingStep['phase']
  readonly rawSteps: readonly PhoneRunStep[]
  readonly rawPendingStep?: PhonePendingStep
}

type Translate = (key: SemanticCopyKey) => string

type SemanticCopyKey =
  | 'semantic.openApp' | 'semantic.openAppGoal' | 'semantic.openAppAction' | 'semantic.openAppSuccess'
  | 'semantic.enterSearch' | 'semantic.enterSearchGoal' | 'semantic.tapTarget' | 'semantic.searchOpened'
  | 'semantic.selectTarget' | 'semantic.selectedTarget' | 'semantic.executeSearch' | 'semantic.searchResults'
  | 'semantic.inputText' | 'semantic.inputGoal' | 'semantic.inputAction' | 'semantic.inputSuccess'
  | 'semantic.inputFailure' | 'semantic.retryCount' | 'semantic.adjustInput' | 'semantic.reactivateInput'
  | 'semantic.useHistory' | 'semantic.useHistoryReason' | 'semantic.strategyReason'
  | 'semantic.back' | 'semantic.home' | 'semantic.scroll' | 'semantic.wait' | 'semantic.waitResult'
  | 'semantic.complete' | 'semantic.taskCompleted' | 'semantic.operation' | 'semantic.tapPage'
  | 'semantic.pressKey' | 'semantic.setupInput' | 'semantic.actionSucceeded' | 'semantic.actionFailed'
  | 'semantic.screenChanged' | 'semantic.screenUnchanged' | 'semantic.pending' | 'semantic.failureJudgment'
  | 'semantic.roleTextField' | 'semantic.roleButton' | 'semantic.roleSwitch' | 'semantic.rolePage'
  | 'steps.title' | 'steps.completed' | 'steps.count' | 'steps.problem' | 'steps.executing' | 'steps.deciding'
  | 'activity.observing' | 'activity.executing' | 'activity.awaiting_approval' | 'activity.stabilizing' | 'activity.verifying'

function template(value: string, replacements: Readonly<Record<string, string | number>> = {}): string {
  return Object.entries(replacements).reduce(
    (result, [key, replacement]) => result.replaceAll(`{${key}}`, String(replacement)),
    value,
  )
}

function targetFor(step: PhoneRunStep): PhoneStepTarget | undefined {
  if (step.context?.target !== undefined) return step.context.target
  if (step.action.type !== 'tap_element') return undefined
  const elementId = step.action.elementId
  const element = step.result.observation?.elements?.find(candidate => candidate.id === elementId)
  if (element === undefined) return undefined
  return {
    elementId: element.id,
    ...(element.contentDescription === undefined ? {} : { accessibilityLabel: element.contentDescription }),
    ...(element.text === undefined ? {} : { text: element.text }),
    role: element.editable ? 'text_field' : element.className.endsWith('Button') ? 'button' : 'control',
    ...(element.resourceId === undefined ? {} : { resourceId: element.resourceId }),
  }
}

function targetLabel(target: PhoneStepTarget | undefined, t: Translate): string | undefined {
  return [target?.accessibilityLabel, target?.text, roleLabel(target?.role, t)]
    .find(value => value !== undefined && value.trim() !== '')
}

function roleLabel(role: string | undefined, t: Translate): string | undefined {
  switch (role) {
    case 'text_field': return t('semantic.roleTextField')
    case 'button': return t('semantic.roleButton')
    case 'switch': return t('semantic.roleSwitch')
    case 'scroll_container': return t('semantic.rolePage')
    default: return undefined
  }
}

function isSearchLabel(label: string | undefined): boolean {
  return label !== undefined && /搜索|search|查找|find/iu.test(label)
}

function textValue(action: PhoneAction): string | undefined {
  return action.type === 'input_text' || action.type === 'replace_text' ? action.text : undefined
}

function appName(packageName: string, task: string): string {
  const known: readonly [RegExp, string][] = [
    [/taobao/iu, /淘宝/u.test(task) ? '淘宝' : 'Taobao'],
    [/settings/iu, /设置/u.test(task) ? '设置' : 'Settings'],
    [/(?:chrome|browser)/iu, /浏览器/u.test(task) ? '浏览器' : 'Browser'],
  ]
  return known.find(([pattern]) => pattern.test(packageName))?.[1]
    ?? packageName.split('.').filter(Boolean).at(-1)?.replaceAll('_', ' ')
    ?? packageName
}

function verificationOf(verification: PhoneVerification, t: Translate): SemanticVerification {
  const facts = verification.facts
  return {
    summary: t(verification.changed ? 'semantic.screenChanged' : 'semantic.screenUnchanged'),
    changed: verification.changed,
    ...(facts === undefined ? legacyVerificationFacts(verification) : {
      uiHierarchyChanged: facts.uiHierarchyChanged,
      screenshotChanged: facts.screenshotChanged,
      foregroundPackageChanged: facts.foregroundPackageChanged,
      activityChanged: facts.activityChanged,
    }),
  }
}

function legacyVerificationFacts(verification: PhoneVerification): Partial<SemanticVerification> {
  const evidence = verification.evidence.join('\n')
  return {
    uiHierarchyChanged: /UI hierarchy changed/iu.test(evidence),
    screenshotChanged: /screenshot changed/iu.test(evidence),
    foregroundPackageChanged: /foreground package changed/iu.test(evidence),
    activityChanged: /activity changed/iu.test(evidence),
  }
}

function baseStep(step: PhoneRunStep, run: PhoneRunView, t: Translate): Omit<SemanticAgentStep, 'index'> {
  const action = step.action
  const success = step.result.verification.success
  const status: AgentStepStatus = success ? 'success' : step.result.executed ? 'warning' : 'error'
  const common = {
    id: String(step.result.actionId),
    type: (success ? 'action' : 'failure') as AgentStepType,
    status,
    verification: verificationOf(step.result.verification, t),
    ...(success ? {} : { judgment: t('semantic.failureJudgment') }),
    rawSteps: [step],
  }

  switch (action.type) {
    case 'open_app': {
      const app = appName(action.packageName, run.task)
      return {
        ...common,
        title: template(t('semantic.openApp'), { app }),
        description: template(t('semantic.openAppAction'), { app }),
        goal: template(t('semantic.openAppGoal'), { app }),
        actionSummary: template(t('semantic.openAppAction'), { app }),
        resultSummary: success ? template(t('semantic.openAppSuccess'), { app }) : t('semantic.actionFailed'),
      }
    }
    case 'tap_element': {
      const label = targetLabel(targetFor(step), t)
      const search = isSearchLabel(label)
      return {
        ...common,
        title: search ? t('semantic.enterSearch') : label === undefined
          ? t('semantic.operation')
          : template(t('semantic.selectTarget'), { target: label }),
        description: label === undefined
          ? t('semantic.tapPage')
          : template(t('semantic.tapTarget'), { target: label }),
        ...(search ? { goal: t('semantic.enterSearchGoal') } : {}),
        actionSummary: label === undefined ? t('semantic.tapPage') : template(t('semantic.tapTarget'), { target: label }),
        resultSummary: success
          ? search ? t('semantic.searchOpened') : template(t('semantic.selectedTarget'), { target: label ?? '' })
          : t('semantic.actionFailed'),
      }
    }
    case 'input_text':
    case 'replace_text': {
      const value = action.text
      return {
        ...common,
        title: template(t('semantic.inputText'), { value }),
        description: success ? t('semantic.inputSuccess') : t('semantic.inputFailure'),
        goal: t('semantic.inputGoal'),
        actionSummary: template(t('semantic.inputAction'), { value }),
        resultSummary: success ? t('semantic.inputSuccess') : t('semantic.inputFailure'),
      }
    }
    case 'press_key': {
      const search = action.key === 'enter'
      return {
        ...common,
        title: search ? t('semantic.executeSearch') : template(t('semantic.pressKey'), { key: action.key }),
        description: success && search ? t('semantic.searchResults') : template(t('semantic.pressKey'), { key: action.key }),
        actionSummary: template(t('semantic.pressKey'), { key: action.key }),
        resultSummary: success ? search ? t('semantic.searchResults') : t('semantic.actionSucceeded') : t('semantic.actionFailed'),
      }
    }
    case 'back': return { ...common, title: t('semantic.back'), description: t('semantic.actionSucceeded'), resultSummary: success ? t('semantic.actionSucceeded') : t('semantic.actionFailed') }
    case 'home': return { ...common, title: t('semantic.home'), description: t('semantic.actionSucceeded'), resultSummary: success ? t('semantic.actionSucceeded') : t('semantic.actionFailed') }
    case 'swipe': return { ...common, title: t('semantic.scroll'), description: t('semantic.screenChanged'), resultSummary: success ? t('semantic.screenChanged') : t('semantic.actionFailed') }
    case 'wait': return { ...common, type: 'observation', title: t('semantic.wait'), description: t('semantic.waitResult'), resultSummary: t('semantic.waitResult') }
    case 'setup_unicode_input': return { ...common, type: 'strategy_change', title: t('semantic.setupInput'), description: t('semantic.setupInput'), resultSummary: success ? t('semantic.actionSucceeded') : t('semantic.actionFailed') }
    case 'finish': return { ...common, type: success ? 'verification' : 'failure', title: t('semantic.complete'), description: action.message || t('semantic.taskCompleted'), resultSummary: action.message || t('semantic.taskCompleted') }
    case 'tap':
    case 'long_press': return { ...common, title: t('semantic.operation'), description: t('semantic.tapPage'), actionSummary: t('semantic.tapPage'), resultSummary: success ? t('semantic.actionSucceeded') : t('semantic.actionFailed') }
  }
}

function pendingStep(step: PhonePendingStep, t: Translate): Omit<SemanticAgentStep, 'index'> {
  const value = textValue(step.action)
  const title = value === undefined
    ? step.action.type === 'open_app'
      ? template(t('semantic.openApp'), { app: appName(step.action.packageName, '') })
      : t('semantic.operation')
    : template(t('semantic.inputText'), { value })
  return {
    id: `pending-${String(step.actionId)}`,
    type: 'action',
    status: 'pending',
    title,
    description: t(`activity.${step.phase}`),
    pendingPhase: step.phase,
    rawSteps: [],
    rawPendingStep: step,
  }
}

function sameFailedText(left: PhoneRunStep, right: PhoneRunStep): boolean {
  const leftText = textValue(left.action)
  return leftText !== undefined
    && leftText === textValue(right.action)
    && !left.result.verification.success
    && !right.result.verification.success
}

function strategyAfterFailure(
  failed: SemanticAgentStep,
  next: PhoneRunStep,
  t: Translate,
): Omit<SemanticAgentStep, 'index'> | undefined {
  const failedRaw = failed.rawSteps.at(-1)
  if (failedRaw === undefined) return undefined
  const value = textValue(failedRaw.action)
  if (value === undefined) return undefined
  const failedAction = failedRaw.action
  const target = targetFor(next)
  const label = targetLabel(target, t)
  const history = next.action.type === 'tap_element'
    && label !== undefined
    && label.includes(value)
    && target?.role !== 'text_field'
  const changedMechanism = next.action.type === 'tap_element'
    || next.action.type === 'tap'
    || (textValue(next.action) !== undefined && next.action.type !== failedAction.type)
  if (!changedMechanism) return undefined
  return {
    id: `strategy-${String(next.result.actionId)}`,
    type: 'strategy_change',
    status: 'info',
    title: history ? t('semantic.useHistory') : t('semantic.adjustInput'),
    description: history ? t('semantic.useHistoryReason') : t('semantic.reactivateInput'),
    reason: t('semantic.strategyReason'),
    resultSummary: history ? t('semantic.useHistoryReason') : t('semantic.reactivateInput'),
    rawSteps: [],
  }
}

/** Convert raw chronological tool actions into a user-facing execution trace. */
export function buildSemanticAgentSteps(run: PhoneRunView, t: Translate): readonly SemanticAgentStep[] {
  const projected: Omit<SemanticAgentStep, 'index'>[] = []
  for (let cursor = 0; cursor < run.steps.length; cursor++) {
    const raw = run.steps[cursor]!
    const previous = projected.at(-1)
    if (previous?.type === 'failure') {
      const strategy = strategyAfterFailure(previous as SemanticAgentStep, raw, t)
      if (strategy !== undefined) {
        projected[projected.length - 1] = { ...previous, nextStep: strategy.description }
        projected.push(strategy)
      }
    }

    if (textValue(raw.action) !== undefined && !raw.result.verification.success) {
      const retries = [raw]
      while (cursor + 1 < run.steps.length && sameFailedText(raw, run.steps[cursor + 1]!)) {
        retries.push(run.steps[++cursor]!)
      }
      const semantic = baseStep(retries.at(-1)!, run, t)
      projected.push({
        ...semantic,
        id: retries.map(step => String(step.result.actionId)).join(':'),
        description: template(t('semantic.retryCount'), { count: retries.length }),
        resultSummary: `${t('semantic.inputFailure')} · ${template(t('semantic.retryCount'), { count: retries.length })}`,
        retryCount: retries.length,
        rawSteps: retries,
      })
      continue
    }

    projected.push(baseStep(raw, run, t))
  }

  if (run.pendingStep !== undefined) projected.push(pendingStep(run.pendingStep, t))
  return projected.map((step, index) => ({ ...step, index: index + 1 }))
}

/** Header copy whose count follows semantic execution steps, not reasoning turns. */
export function semanticRunTitle(run: PhoneRunView | undefined, stepCount: number, t: Translate): string {
  if (run === undefined) return t('steps.title')
  if (run.status === 'completed') return `${t('steps.completed')} · ${stepCount} ${t('steps.count')}`
  if (run.status === 'failed' || run.status === 'stopped') return t('steps.problem')
  if (run.pendingStep !== undefined || stepCount > 0) return t('steps.executing')
  if (run.activity === 'thinking' || run.status === 'starting') return t('steps.deciding')
  return t('steps.executing')
}
