/** Blank-session-safe Mobile launcher rendered in the resident composer toolbar. */

import { useState } from 'react'
import { Button, Modal } from '@deepseek-ai/dsh-client-ui-primitives'
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import { PhoneAgentView } from './PhoneAgentView.tsx'
import type { PhoneAgentPanelProps } from './PhoneAgentView.tsx'
import css from './MobileLauncher.module.css'

/** Full props supplied by the session-scoped composer toolbar entry. */
export type MobileLauncherProps = PropsRuntime<'conversation.input.left'> & PhoneAgentPanelProps

/** Open the complete Mobile task panel without requiring a prior chat turn. */
export function MobileLauncher(props: MobileLauncherProps) {
  const [open, setOpen] = useState(false)
  const { t } = props

  return (
    <>
      <Button size="sm" variant="toolbar" onClick={() => { setOpen(true) }}>
        {t('launcher.open')}
      </Button>
      <Modal
        open={open}
        onClose={() => { setOpen(false) }}
        title={t('view.phone')}
        closeLabel={t('launcher.close')}
        className={css.dialog!}
      >
        <div className={css.panel}>
          <PhoneAgentView {...props} />
        </div>
      </Modal>
    </>
  )
}
