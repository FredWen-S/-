/** Strict Phone action tool schema and wire conversion. */

import { PhoneObservationId } from '../core/index.ts'
import type { PhoneAction, PhoneKey } from '../core/index.ts'
import type {
  ObjectValueSchemaSpec,
  ParameterPropertySpec,
  ParameterSchemaSpec,
  ValueSchemaSpec,
} from '@deepseek-ai/dsh-tools'

/** Phone key names accepted on the model wire. */
export const PHONE_KEYS = ['enter', 'delete', 'tab', 'escape', 'volume_up', 'volume_down', 'power'] as const satisfies readonly PhoneKey[]

const requiredString = (): ParameterPropertySpec => ({ type: 'string', required: true })
const optionalInteger = (): ParameterPropertySpec => ({ type: 'integer' })
const requiredInteger = (): ParameterPropertySpec => ({ type: 'integer', required: true })
const requiredBoolean = (): ParameterPropertySpec => ({ type: 'boolean', required: true })
const literal = (value: string): ParameterPropertySpec => ({ type: 'string', const: value, required: true })
const enumString = (values: readonly string[]): ParameterPropertySpec => ({ type: 'string', enum: values, required: true })
const object = (properties: ParameterSchemaSpec): ObjectValueSchemaSpec => ({
  type: 'object',
  additionalProperties: false,
  properties,
})

/** Exact-one schema for all model-selectable Phone actions. */
export const PHONE_ACTION_SCHEMA = {
  oneOf: [
    object({ type: literal('tap_element'), observation_id: requiredString(), element_id: requiredInteger() }),
    object({ type: literal('tap'), x: requiredInteger(), y: requiredInteger() }),
    object({ type: literal('long_press'), x: requiredInteger(), y: requiredInteger(), duration_ms: optionalInteger() }),
    object({ type: literal('swipe'), x1: requiredInteger(), y1: requiredInteger(), x2: requiredInteger(), y2: requiredInteger(), duration_ms: optionalInteger() }),
    object({ type: literal('input_text'), text: requiredString() }),
    object({ type: literal('replace_text'), text: requiredString() }),
    object({ type: literal('setup_unicode_input') }),
    object({ type: literal('press_key'), key: enumString(PHONE_KEYS) }),
    object({ type: literal('back') }),
    object({ type: literal('home') }),
    object({ type: literal('open_app'), package_name: requiredString() }),
    object({ type: literal('wait'), ms: requiredInteger() }),
    object({ type: literal('finish'), success: requiredBoolean(), message: requiredString() }),
  ],
} as const satisfies ValueSchemaSpec

/** Complete `phone_act` parameter root. */
export const PHONE_ACTION_PARAMETERS = {
  action: {
    oneOf: [
      ...PHONE_ACTION_SCHEMA.oneOf,
      object({ action: { ...PHONE_ACTION_SCHEMA, required: true } }),
    ],
    required: true,
  },
} as const satisfies ParameterSchemaSpec

/**
 * Convert one schema-validated wire action into the shared canonical union.
 * @param value - Value accepted by {@link PHONE_ACTION_SCHEMA}.
 * @returns Canonical camelCase action.
 */
export function parsePhoneAction(value: unknown): PhoneAction {
  const outer = record(value)
  const action = outer.type === undefined && outer.action !== undefined ? record(outer.action) : outer
  switch (action.type) {
    case 'tap_element':
      return {
        type: 'tap_element',
        observationId: PhoneObservationId(nonEmptyString(action.observation_id, 'observation_id')),
        elementId: positiveInteger(action.element_id, 'element_id'),
      }
    case 'tap':
      return { type: 'tap', x: integer(action.x, 'x'), y: integer(action.y, 'y') }
    case 'long_press':
      return {
        type: 'long_press',
        x: integer(action.x, 'x'),
        y: integer(action.y, 'y'),
        ...optionalDuration(action.duration_ms),
      }
    case 'swipe':
      return {
        type: 'swipe',
        x1: integer(action.x1, 'x1'),
        y1: integer(action.y1, 'y1'),
        x2: integer(action.x2, 'x2'),
        y2: integer(action.y2, 'y2'),
        ...optionalDuration(action.duration_ms),
      }
    case 'input_text':
      return { type: 'input_text', text: nonEmptyString(action.text, 'text', false) }
    case 'replace_text':
      return { type: 'replace_text', text: nonEmptyString(action.text, 'text', false) }
    case 'setup_unicode_input': return { type: 'setup_unicode_input' }
    case 'press_key':
      return { type: 'press_key', key: phoneKey(action.key) }
    case 'back': return { type: 'back' }
    case 'home': return { type: 'home' }
    case 'open_app': return { type: 'open_app', packageName: nonEmptyString(action.package_name, 'package_name') }
    case 'wait': return { type: 'wait', ms: boundedPositiveInteger(action.ms, 'ms', 60_000) }
    case 'finish':
      return {
        type: 'finish',
        success: action.success as boolean,
        message: nonEmptyString(action.message, 'message'),
      }
    default: throw new Error(`phone_act: unknown action type ${JSON.stringify(action.type)}`)
  }
}

/** Require one object at the action wire boundary. */
function record(value: unknown): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('phone_act: action must be an object')
  }
  return value as Record<string, unknown>
}

/** Materialize a bounded optional duration. */
function optionalDuration(value: unknown): { readonly durationMs?: number } {
  return value === undefined ? {} : { durationMs: boundedPositiveInteger(value, 'duration_ms', 60_000) }
}

/** Require a safe integer. */
function integer(value: unknown, field: string): number {
  if (!Number.isSafeInteger(value)) throw new Error(`phone_act: ${field} must be a safe integer`)
  return value as number
}

/** Require a positive safe integer. */
function positiveInteger(value: unknown, field: string): number {
  const number = integer(value, field)
  if (number < 1) throw new Error(`phone_act: ${field} must be positive`)
  return number
}

/** Require a bounded positive safe integer. */
function boundedPositiveInteger(value: unknown, field: string, maximum: number): number {
  const number = positiveInteger(value, field)
  if (number > maximum) throw new Error(`phone_act: ${field} must be at most ${maximum}`)
  return number
}

/** Require a string and optionally permit an empty value for text entry. */
function nonEmptyString(value: unknown, field: string, requireContent = true): string {
  if (typeof value !== 'string') throw new Error(`phone_act: ${field} must be a string`)
  if (requireContent && value.trim().length === 0) throw new Error(`phone_act: ${field} must be non-empty`)
  return value
}

/** Narrow a validated key to the shared closed vocabulary. */
function phoneKey(value: unknown): PhoneKey {
  if (typeof value !== 'string' || !PHONE_KEYS.includes(value as PhoneKey)) {
    throw new Error(`phone_act: unknown key ${JSON.stringify(value)}`)
  }
  return value as PhoneKey
}
