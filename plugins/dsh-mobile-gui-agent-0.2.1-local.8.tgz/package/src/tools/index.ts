/** Agent-scoped model-facing Phone observation and single-action tools. */

import type { Context } from '@deepseek-ai/cordis'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import { snapshotJsonValue } from '@deepseek-ai/dsh-session'
import type { JsonValue } from '@deepseek-ai/dsh-session'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { InferValue, ToolRunContext, ValueSchemaSpec } from '@deepseek-ai/dsh-tools'
import { PhoneDeviceId, PhoneError } from '../core/index.ts'
import { PHONE_ACTION_PARAMETERS, parsePhoneAction } from './schema.ts'

export { PHONE_ACTION_PARAMETERS, PHONE_ACTION_SCHEMA, PHONE_KEYS, parsePhoneAction } from './schema.ts'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'tool-phone'
/** Active-run and tool-registry dependencies. */
export const inject = ['tools', 'phoneRuns']

const screenshotSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    attachmentId: { type: 'string', required: true },
    mediaType: { type: 'string', required: true, enum: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'] },
    bytes: { type: 'integer', required: true },
    width: { type: 'integer', required: true },
    height: { type: 'integer', required: true },
    name: { type: 'string' },
  },
} as const

const TOOL_OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    text: { type: 'string', required: true },
    payload: { type: 'json', required: true },
    screenshot: screenshotSchema,
  },
} as const satisfies ValueSchemaSpec

const toolOutput = {
  schema: TOOL_OUTPUT_SCHEMA,
  render: (_args: unknown, value: InferValue<typeof TOOL_OUTPUT_SCHEMA>): ContentBlock[] => [
    { type: 'text' as const, text: value.text },
    ...(value.screenshot === undefined
      ? []
      : [{ type: 'image' as const, attachment: value.screenshot as ImageAttachmentRef }]),
  ],
} as const

/**
 * Register the two scoped Phone tools on the current context.
 * @param ctx - Agent-scoped context carrying `ctx.phoneRuns` and `ctx.tools`.
 */
export function apply(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: 'phone_observe',
    description: 'Observe the current Android screen and compact interactive UI before choosing one action.',
    parameters: {},
    output: toolOutput,
    async execute(_args, execution) {
      const result = await ctx.phoneRuns.observe(requireAgent(execution), execution.signal)
      return outputValue(result.text, result, result.observation.screenshot)
    },
  }))
  ctx.tools.register(defineTool({
    name: 'phone_act',
    description: 'Execute exactly one Android action, wait for stabilization, verify it, and return the next observation. Pass one direct action object, for example {"action":{"type":"tap","x":100,"y":200}}; do not nest another action key.',
    parameters: PHONE_ACTION_PARAMETERS,
    output: toolOutput,
    async execute(args, execution) {
      const result = await ctx.phoneRuns.act(requireAgent(execution), parsePhoneAction(args.action), execution)
      return outputValue(result.text, result, result.observation.screenshot)
    },
  }))
}

/**
 * Register the chat-facing `phone_start_task` tool on the host registry.
 *
 * It is visible to ordinary chat; an active run's tool restriction hides it, so a
 * Phone task can never schedule another. The run itself starts after this turn
 * ends, through the same `start()` path as the Mobile panel.
 * @param ctx - Host context carrying `ctx.phoneRuns` and `ctx.tools`.
 */
export function applyStarter(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: 'phone_start_task',
    description: 'Start a task on the user\'s connected Android phone, such as checking a setting, opening an app, or reading something on screen. '
      + 'Call it only when the user explicitly asks you to look at or operate their phone; never for questions about how something works, '
      + 'instructions, or writing code. Put the user\'s request in task, in their language, without adding steps or goals. '
      + 'Pass device_id only when the user named a device or an earlier call reported several devices. '
      + 'In the same response, tell the user in one short sentence that you are starting on the phone: the reply ends right after this call, '
      + 'then the task runs in this conversation and its steps and result appear in the Mobile panel.',
    parameters: {
      task: { type: 'string', required: true, description: 'What to do or find out on the phone, as the user asked it.' },
      device_id: { type: 'string', description: 'ADB serial of the device, only when several are online or the user named one.' },
    },
    output: toolOutput,
    async execute(args, execution) {
      const agent = requireAgent(execution)
      const deviceId = typeof args.device_id === 'string' && args.device_id.trim().length > 0
        ? PhoneDeviceId(args.device_id.trim())
        : undefined
      try {
        const scheduled = await ctx.phoneRuns.scheduleStart(agent, {
          task: args.task,
          ...(deviceId === undefined ? {} : { deviceId }),
        }, execution.signal)
        execution.concludeTurn()
        return outputValue(
          `Phone task accepted on ${scheduled.deviceId}: "${scheduled.task}". It starts in this conversation as soon as this reply ends.`,
          { scheduled: true, deviceId: scheduled.deviceId, task: scheduled.task },
          undefined,
        )
      } catch (error: unknown) {
        if (!(error instanceof PhoneError)) throw error
        // Not concluded: the model explains, or asks which device, in this same reply.
        return outputValue(
          `PHONE_TASK_NOT_STARTED ${error.code}: ${error.message}`,
          { scheduled: false, error: { code: error.code, message: error.message } },
          undefined,
        )
      }
    },
  }))
}

/**
 * Register the chat-facing `phone_run_task` tool (Phase A prototype, `chatEntry: executor`).
 *
 * The call runs the task on a child-session executor Agent and waits for its terminal
 * state, so the chat model reports the actual result. Cancelling this call (the chat's
 * stop) stops the executor's run directly.
 * @param ctx - Host context carrying `ctx.phoneRuns` and `ctx.tools`.
 */
export function applyRunner(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: 'phone_run_task',
    description: 'Run a task on the user\'s connected Android phone, such as checking a setting, opening an app, or reading something on screen, and wait for the result. '
      + 'Call it only when the user explicitly asks you to look at or operate their phone; never for questions about how something works, '
      + 'instructions, or writing code. Put the user\'s request in task, in their language, without adding steps or goals. '
      + 'Pass device_id only when the user named a device or an earlier call reported several devices. '
      + 'The call returns when the phone task ends, usually within a few minutes. Then answer the user from the returned status and message only: '
      + 'if status is not completed, say the task was not completed and why; never claim more than the message states. '
      + 'A phone_run_task call that ended as "tool call aborted" or with status stopped was stopped by the user on purpose: '
      + 'never run that task again, and do not offer to, unless the user asks for it again.',
    parameters: {
      task: { type: 'string', required: true, description: 'What to do or find out on the phone, as the user asked it.' },
      device_id: { type: 'string', description: 'ADB serial of the device, only when several are online or the user named one.' },
    },
    output: toolOutput,
    async execute(args, execution) {
      const agent = requireAgent(execution)
      const deviceId = typeof args.device_id === 'string' && args.device_id.trim().length > 0
        ? PhoneDeviceId(args.device_id.trim())
        : undefined
      try {
        const result = await ctx.phoneRuns.runInExecutor(agent, {
          task: args.task,
          ...(deviceId === undefined ? {} : { deviceId }),
        }, execution.signal)
        return outputValue(
          [
            `Phone task ${result.status} on ${result.deviceId} after ${result.steps} step(s) in ${Math.round(result.durationMs / 1000)}s.`,
            `Result: ${result.message ?? '(no message)'}`,
            ...(result.status === 'completed' ? [] : ['The task did not complete; tell the user what is known and what is not.']),
            ...(result.status === 'stopped' ? ['It was stopped on purpose; do not run it again unless the user asks.'] : []),
          ].join('\n'),
          result,
          undefined,
        )
      } catch (error: unknown) {
        if (!(error instanceof PhoneError)) throw error
        return outputValue(
          `PHONE_TASK_NOT_STARTED ${error.code}: ${error.message}`,
          { status: 'not_started', error: { code: error.code, message: error.message } },
          undefined,
        )
      }
    },
  }))
}

/** Terminal run state exposed by the safe inactive Phone tool facade. */
export interface InactivePhoneToolState {
  readonly status: string
  readonly message?: string
}

/**
 * Register no-op Phone tools after the real run scope has ended.
 *
 * Keeping the public names resolvable prevents a model from hitting Harness's
 * UNKNOWN_TOOL path when conversation history contains earlier Phone calls.
 * These implementations never resolve a device or execute an Android action.
 */
export function applyInactive(ctx: Context, state: InactivePhoneToolState): void {
  ctx.tools.register(defineTool({
    name: 'phone_observe',
    description: 'Inactive Phone safety guard. The previous Phone task has ended; this only reports PHONE_RUN_NOT_ACTIVE and never reads a device.',
    parameters: {},
    output: toolOutput,
    async execute() {
      return inactiveOutput(state)
    },
  }))
  ctx.tools.register(defineTool({
    name: 'phone_act',
    description: 'Inactive Phone safety guard. The previous Phone task has ended; this only reports PHONE_RUN_NOT_ACTIVE and never performs an action.',
    parameters: PHONE_ACTION_PARAMETERS,
    output: toolOutput,
    async execute() {
      return inactiveOutput(state)
    },
  }))
}

/** Require the Agent ownership that gives a Phone run meaning. */
function requireAgent(execution: ToolRunContext): NonNullable<ToolRunContext['agent']> {
  if (execution.agent === undefined) throw new Error('Phone tools require an owning Agent')
  return execution.agent
}

/** Convert a typed result to the lossless JSON output boundary. */
function outputValue(
  text: string,
  result: unknown,
  screenshot: ImageAttachmentRef | undefined,
): InferValue<typeof TOOL_OUTPUT_SCHEMA> {
  const payload = snapshotJsonValue(result) as JsonValue | undefined
  if (payload === undefined) throw new Error('Phone tool result is not lossless JSON')
  return {
    text,
    payload,
    ...(screenshot === undefined ? {} : { screenshot }),
  }
}

/** Build a deterministic, device-free result for a stale Phone tool call. */
function inactiveOutput(state: InactivePhoneToolState): InferValue<typeof TOOL_OUTPUT_SCHEMA> {
  const recovery = 'Start a new Phone task with phone_start_task when the user asks, or from the Mobile view.'
  const text = `PHONE_RUN_NOT_ACTIVE: The previous Phone task is ${state.status} and has ended. Ordinary chat text cannot approve or resume it. ${recovery}`
  return outputValue(text, {
    active: false,
    error: {
      code: 'PHONE_RUN_NOT_ACTIVE',
      message: text,
    },
    run: {
      status: state.status,
      ...(state.message === undefined ? {} : { message: state.message }),
    },
    recovery,
  }, undefined)
}
