# Changelog

All notable changes to `dsh-mobile-gui-agent` are documented here.

## 0.2.1 - 2026-08-20

### Added

- Added a semantic execution trace that groups low-level Android actions into user-readable task steps, while preserving expandable technical diagnostics.
- Added live action phases for observation, execution, approval, screen stabilization, and verification.
- Added structured verification facts and pre-action target context for dependable debugging of Agent decisions.
- Added illustrated demos for opening Android Settings to Wi-Fi and opening Taobao.

### Fixed

- Preserve an active Mobile Agent run across Web view remounts, including the selected device and task state.

## 0.2.0 - 2026-08-15

### Added

- Added a blank-session `mobile_gui_agent` launcher while retaining the regular conversation tab.
- Added transparent Unicode input through an installed ADB Keyboard helper, with temporary activation and exact input-method restoration.
- Added atomic `replace_text` support so the Agent can replace focused text without repeated Delete actions.
- Added an illustrated, bilingual recommended workflow that keeps phone commands inside the `mobile_gui_agent` task field.

### Fixed

- Verify text actions against focused-field content instead of treating unrelated screen animation as success.
- Revalidate semantic targets locally so dynamic recommendations and other unrelated page updates do not invalidate a still-stable target.
- Normalize approval cancellation, abort reasons, and terminal tool handling so user cancellation does not surface as `[object Object]` or leave the device reserved.
- Improve HyperOS and MIUI foreground, keyboard, and window-state parsing.

## 0.1.1 - 2026-08-14

- Renamed the standalone package and public plugin identity to `dsh-mobile-gui-agent`.
- Published the initial GitHub release and installable standalone package artifacts.
