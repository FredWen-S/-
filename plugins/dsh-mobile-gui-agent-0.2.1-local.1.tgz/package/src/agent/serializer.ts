/** Compact model text for Phone observations and action outcomes. */

import type { PhoneActionResult, PhoneObservation, PhoneVisionObservation } from '../core/index.ts'
import { serializePhoneElement } from '../core/serialize.ts'

/**
 * Serialize one observation without raw XML or repeated empty attributes.
 * @param task - Current user task.
 * @param observation - JSON-safe current Phone state.
 * @param vision - Optional replaceable visual analysis.
 * @returns Token-optimized model text.
 */
export function serializePhoneObservation(
  task: string,
  observation: PhoneObservation,
  vision?: PhoneVisionObservation,
): string {
  const lines = [
    `Task: ${task}`,
    `Observation: ${observation.id}`,
    `Device: ${observation.deviceId} ${observation.width}x${observation.height} ${observation.orientation}`,
    `Foreground: ${observation.foregroundPackage ?? 'unknown'} ${observation.activity ?? ''}`.trim(),
    `Keyboard: ${observation.keyboardVisible === undefined ? 'unknown' : observation.keyboardVisible ? 'visible' : 'hidden'}; locked: ${observation.locked === undefined ? 'unknown' : String(observation.locked)}`,
    ...(observation.hierarchyUnavailable === undefined
      ? [
          'Interactive UI:',
          ...(observation.elements.length === 0 ? ['[no meaningful UI elements]'] : observation.elements.map(serializePhoneElement)),
        ]
      : [
          `Interactive UI: unavailable (${observation.hierarchyUnavailable})`,
          '[element ids cannot be used on this screen; judge progress from Foreground and any screenshot or visual analysis, and use coordinate actions]',
        ]),
  ]
  if (observation.hierarchyTruncated) lines.push('[hierarchy truncated]')
  if (vision !== undefined) {
    lines.push(`Visual analysis: ${vision.summary}`)
    lines.push(...vision.visualElements.map(element => `Visual: ${element}`))
  }
  return lines.join('\n')
}

/**
 * Serialize one verified result beside its fresh observation.
 * @param result - Canonical action result.
 * @param observationText - Already serialized next observation.
 * @returns Compact action and evidence summary.
 */
export function serializePhoneActionResult(result: PhoneActionResult, observationText: string): string {
  const lines = [
    `Action ${result.actionId}: ${result.action.type}`,
    `Executed: ${String(result.executed)}; verified: ${String(result.verification.success)}; changed: ${String(result.verification.changed)}`,
    ...result.verification.evidence.map(evidence => `Evidence: ${evidence}`),
  ]
  if (result.error !== undefined) lines.push(`Error ${result.error.code}: ${result.error.message}`)
  if (result.stability !== undefined) {
    lines.push(result.stability.timedOut
      ? `Settle: deadline reached (non-fatal); samples: ${result.stability.samples}`
      : `Settle: stable; samples: ${result.stability.samples}`)
  }
  if (result.stuck.stuck) lines.push(`Stuck: ${result.stuck.reason}; try ${result.stuck.recovery}`)
  lines.push('', observationText)
  return lines.join('\n')
}
