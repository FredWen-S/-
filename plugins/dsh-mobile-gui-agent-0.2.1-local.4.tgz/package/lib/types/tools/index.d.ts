/** Agent-scoped model-facing Phone observation and single-action tools. */
import type { Context } from '@deepseek-ai/cordis';
export { PHONE_ACTION_PARAMETERS, PHONE_ACTION_SCHEMA, PHONE_KEYS, parsePhoneAction } from './schema.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "tool-phone";
/** Active-run and tool-registry dependencies. */
export declare const inject: string[];
/**
 * Register the two scoped Phone tools on the current context.
 * @param ctx - Agent-scoped context carrying `ctx.phoneRuns` and `ctx.tools`.
 */
export declare function apply(ctx: Context): void;
/**
 * Register the chat-facing `phone_start_task` tool on the host registry.
 *
 * It is visible to ordinary chat; an active run's tool restriction hides it, so a
 * Phone task can never schedule another. The run itself starts after this turn
 * ends, through the same `start()` path as the Mobile panel.
 * @param ctx - Host context carrying `ctx.phoneRuns` and `ctx.tools`.
 */
export declare function applyStarter(ctx: Context): void;
/** Terminal run state exposed by the safe inactive Phone tool facade. */
export interface InactivePhoneToolState {
    readonly status: string;
    readonly message?: string;
}
/**
 * Register no-op Phone tools after the real run scope has ended.
 *
 * Keeping the public names resolvable prevents a model from hitting Harness's
 * UNKNOWN_TOOL path when conversation history contains earlier Phone calls.
 * These implementations never resolve a device or execute an Android action.
 */
export declare function applyInactive(ctx: Context, state: InactivePhoneToolState): void;
//# sourceMappingURL=index.d.ts.map