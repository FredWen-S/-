/** JSON-safe Phone state, action, result, and run vocabulary. */
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { PhoneActionId, PhoneDeviceId, PhoneObservationId, PhoneRunId } from './brand.ts';
import type { PhoneErrorCode } from './error.ts';
export type { PhoneActionId, PhoneDeviceId, PhoneObservationId, PhoneRunId } from './brand.ts';
/** Connection state reported by ADB discovery. */
export type PhoneDeviceStatus = 'device' | 'offline' | 'unauthorized';
/** Android screen orientation inferred from the current display geometry. */
export type PhoneOrientation = 'portrait' | 'landscape' | 'square';
/** Closed key vocabulary accepted by the model-facing action schema. */
export type PhoneKey = 'enter' | 'delete' | 'tab' | 'escape' | 'volume_up' | 'volume_down' | 'power';
/** Provider-side shell classification; arbitrary model-authored commands never cross this API. */
export type PhoneShellPurpose = 'diagnostic' | 'ui-hierarchy' | 'package-resolution' | 'device-state';
/** One device returned by discovery or wireless connection. */
export interface PhoneDeviceInfo {
    /** Provider-owned device identity. */
    readonly id: PhoneDeviceId;
    /** Current ADB state. */
    readonly status: PhoneDeviceStatus;
    /** Android product model when ADB reports it. */
    readonly model?: string;
    /** Android product name when ADB reports it. */
    readonly product?: string;
    /** Transport id when ADB reports it. */
    readonly transportId?: string;
}
/** Visible screen rectangle encoded as left, top, right, bottom pixels. */
export type PhoneBounds = readonly [left: number, top: number, right: number, bottom: number];
/** Compact UIAutomator node retained for semantic model actions. */
export interface PhoneUIElement {
    /** Observation-local short identifier. */
    readonly id: number;
    /** Android class name. */
    readonly className: string;
    /** Visible text, when present. */
    readonly text?: string;
    /** Android resource id, when present. */
    readonly resourceId?: string;
    /** Accessibility content description, when present. */
    readonly contentDescription?: string;
    /** Whether Android reports the node clickable. */
    readonly clickable: boolean;
    /** Whether Android reports long-click support. */
    readonly longClickable: boolean;
    /** Whether Android reports the node scrollable. */
    readonly scrollable: boolean;
    /** Whether text can be edited. */
    readonly editable: boolean;
    /** Whether the node can receive focus. */
    readonly focusable: boolean;
    /** Whether the node currently owns focus. */
    readonly focused: boolean;
    /** Whether the node is enabled. */
    readonly enabled: boolean;
    /** Whether the node is selected. */
    readonly selected: boolean;
    /** Checked state when Android exposes one. */
    readonly checked?: boolean;
    /** Whether Android marks the node as password content. */
    readonly password: boolean;
    /** Visible bounds clipped to the current display. */
    readonly bounds: PhoneBounds;
    /** Stable semantic fingerprint independent from the short id. */
    readonly fingerprint: string;
}
/** Parsed hierarchy and the signatures used for stale-state detection. */
export interface PhoneHierarchy {
    /** Retained compact elements. */
    readonly elements: readonly PhoneUIElement[];
    /** Digest of the compact semantic content. */
    readonly signature: string;
    /** Whether pruning reached an element or byte limit. */
    readonly truncated: boolean;
}
/** Bounded PNG capture with intrinsic metadata. */
export interface PhoneScreenshot {
    /** Encoded PNG bytes. */
    readonly data: Uint8Array;
    /** Intrinsic width in pixels. */
    readonly width: number;
    /** Intrinsic height in pixels. */
    readonly height: number;
    /** Capture time in Unix milliseconds. */
    readonly timestamp: number;
    /** Digest of the exact PNG bytes. */
    readonly digest: string;
    /** Low-resolution comparison signature. */
    readonly comparisonSignature: string;
}
/** JSON-safe observation consumed by tools, bounded run traces, and the UI. */
export interface PhoneObservation {
    /** Observation identity used by semantic actions. */
    readonly id: PhoneObservationId;
    /** Device that produced the observation. */
    readonly deviceId: PhoneDeviceId;
    /** Capture time in Unix milliseconds. */
    readonly timestamp: number;
    /** Current display width. */
    readonly width: number;
    /** Current display height. */
    readonly height: number;
    /** Current display orientation. */
    readonly orientation: PhoneOrientation;
    /** Exact screenshot digest. */
    readonly screenshotDigest: string;
    /** Low-resolution screenshot signature. */
    readonly screenshotSignature: string;
    /** Saved screenshot reference when the image entered model or UI state. */
    readonly screenshot?: ImageAttachmentRef;
    /** Attached screenshot pixels per device pixel, present only when the saved screenshot was downscaled. */
    readonly screenshotScale?: number;
    /** Foreground Android package when detectable. */
    readonly foregroundPackage?: string;
    /** Foreground Android activity when detectable. */
    readonly activity?: string;
    /** Whether the software keyboard appears visible. */
    readonly keyboardVisible?: boolean;
    /** Whether the screen appears locked. */
    readonly locked?: boolean;
    /** Compact retained elements. */
    readonly elements: readonly PhoneUIElement[];
    /** Compact hierarchy digest. */
    readonly uiSignature: string;
    /** Whether hierarchy pruning reached a configured limit. */
    readonly hierarchyTruncated: boolean;
    /** Why the UI hierarchy could not be captured; `elements` is then empty and `uiSignature` carries no UI facts. */
    readonly hierarchyUnavailable?: string;
}
/** Internal observation plus screenshot bytes retained only for immediate consumers. */
export interface PhoneCapture {
    /** JSON-safe state. */
    readonly observation: PhoneObservation;
    /** Screenshot bytes corresponding exactly to the observation. */
    readonly screenshot: PhoneScreenshot;
}
/** Deterministic provider shell request. */
export interface PhoneShellRequest {
    /** Classification used by approval and audit policy. */
    readonly purpose: PhoneShellPurpose;
    /** Arguments passed after `adb -s DEVICE shell`. */
    readonly argv: readonly string[];
    /** Maximum accepted stdout bytes. */
    readonly maxOutputBytes: number;
}
/** Tunables for adaptive stable-screen sampling. */
export interface StableScreenOptions {
    /** Poll interval in milliseconds. */
    readonly pollMs: number;
    /** Required consecutive stable comparisons. */
    readonly stableSamples: number;
    /** Maximum total wait in milliseconds. */
    readonly timeoutMs: number;
    /** Maximum normalized thumbnail difference considered stable. */
    readonly differenceThreshold: number;
}
/** Result of adaptive screen stabilization. */
export interface StableScreenResult {
    /** Last sampled screenshot. */
    readonly screenshot: PhoneScreenshot;
    /** Whether enough consecutive samples were stable. */
    readonly stable: boolean;
    /** Whether the configured deadline ended sampling. */
    readonly timedOut: boolean;
    /** Number of screenshots sampled. */
    readonly samples: number;
    /** Last normalized comparison difference. */
    readonly difference: number;
}
/** Live provider handle bound to one Android device. */
export interface PhoneDevice {
    /** Bound device identity. */
    readonly id: PhoneDeviceId;
    /**
     * Capture a coherent screenshot, hierarchy, display, and foreground state.
     * @param signal - Cooperative cancellation.
     * @returns Internal capture with matching bytes and JSON observation.
     */
    getState(signal?: AbortSignal): Promise<PhoneCapture>;
    /**
     * Capture a bounded PNG screenshot.
     * @param signal - Cooperative cancellation.
     * @returns Encoded image and intrinsic metadata.
     */
    screenshot(signal?: AbortSignal): Promise<PhoneScreenshot>;
    /**
     * Capture and prune the UIAutomator hierarchy.
     * @param signal - Cooperative cancellation.
     * @returns Compact hierarchy.
     */
    getUIHierarchy(signal?: AbortSignal): Promise<PhoneHierarchy>;
    /** Tap one display coordinate. */
    tap(x: number, y: number, signal?: AbortSignal): Promise<void>;
    /** Long-press one display coordinate. */
    longPress(x: number, y: number, durationMs: number, signal?: AbortSignal): Promise<void>;
    /** Swipe between two display coordinates. */
    swipe(x1: number, y1: number, x2: number, y2: number, durationMs: number, signal?: AbortSignal): Promise<void>;
    /** Enter text through Android's current focused input. */
    inputText(text: string, signal?: AbortSignal): Promise<void>;
    /** Replace all text in Android's current focused input. */
    replaceText(text: string, signal?: AbortSignal): Promise<void>;
    /** Explicitly authorize and prepare the configured Unicode input helper for this device handle. */
    setupUnicodeInput?(signal?: AbortSignal): Promise<void>;
    /** Press one closed-vocabulary Android key. */
    pressKey(key: PhoneKey, signal?: AbortSignal): Promise<void>;
    /** Navigate back. */
    back(signal?: AbortSignal): Promise<void>;
    /** Navigate home. */
    home(signal?: AbortSignal): Promise<void>;
    /** Launch a package's resolved launcher activity. */
    openApp(packageName: string, signal?: AbortSignal): Promise<void>;
    /** Execute a classified provider-owned Android shell request. */
    shell(request: PhoneShellRequest, signal?: AbortSignal): Promise<string>;
    /** Wait cooperatively without a device side effect. */
    wait(ms: number, signal?: AbortSignal): Promise<void>;
    /** Sample screenshots until the display stabilizes or times out. */
    waitForStableScreen(options: StableScreenOptions, signal?: AbortSignal): Promise<StableScreenResult>;
}
/** Strict one-action vocabulary selected by the Agent. */
export type PhoneAction = {
    readonly type: 'tap_element';
    readonly observationId: PhoneObservationId;
    readonly elementId: number;
} | {
    readonly type: 'tap';
    readonly x: number;
    readonly y: number;
} | {
    readonly type: 'long_press';
    readonly x: number;
    readonly y: number;
    readonly durationMs?: number;
} | {
    readonly type: 'swipe';
    readonly x1: number;
    readonly y1: number;
    readonly x2: number;
    readonly y2: number;
    readonly durationMs?: number;
} | {
    readonly type: 'input_text';
    readonly text: string;
} | {
    readonly type: 'replace_text';
    readonly text: string;
} | {
    readonly type: 'setup_unicode_input';
} | {
    readonly type: 'press_key';
    readonly key: PhoneKey;
} | {
    readonly type: 'back';
} | {
    readonly type: 'home';
} | {
    readonly type: 'open_app';
    readonly packageName: string;
} | {
    readonly type: 'wait';
    readonly ms: number;
} | {
    readonly type: 'finish';
    readonly success: boolean;
    readonly message: string;
};
/** Structured provider or policy error returned to the Agent for recovery. */
export interface PhoneActionError {
    /** Stable error category. */
    readonly code: PhoneErrorCode;
    /** User-safe diagnostic. */
    readonly message: string;
}
/** Verification facts produced after one action. */
export interface PhoneVerification {
    /** Whether observable evidence supports the action's intended effect. */
    readonly success: boolean;
    /** Whether foreground, hierarchy, or screenshot evidence changed. */
    readonly changed: boolean;
    /** Short independent evidence statements. */
    readonly evidence: readonly string[];
    /** Structured state changes used by semantic execution traces. */
    readonly facts?: PhoneVerificationFacts;
}
/** Machine-readable verification dimensions kept out of the default user trace. */
export interface PhoneVerificationFacts {
    readonly foregroundPackageChanged: boolean;
    readonly activityChanged: boolean;
    readonly displayChanged: boolean;
    readonly uiHierarchyChanged: boolean;
    readonly screenshotChanged: boolean;
    readonly textChanged?: boolean;
}
/** Stuck detector outcome attached to an action result. */
export interface PhoneStuckStatus {
    /** Whether recent state/action history indicates a failed strategy. */
    readonly stuck: boolean;
    /** Machine-readable detection reason when stuck. */
    readonly reason?: 'repeated-action' | 'unchanged-failures' | 'state-cycle' | 'stale-observation' | 'device-errors';
    /** Deterministic recovery category suggested to the Agent. */
    readonly recovery?: 'observe' | 'wait' | 'scroll' | 'back' | 'dismiss-popup' | 'choose-another-element';
}
/** Canonical result returned by `phone_act`. */
export interface PhoneActionResult {
    /** Runtime-minted action identity. */
    readonly actionId: PhoneActionId;
    /** Requested action. */
    readonly action: PhoneAction;
    /** Whether a device side effect was attempted. */
    readonly executed: boolean;
    /** Post-action verification. */
    readonly verification: PhoneVerification;
    /** Structured failure when execution was rejected or failed. */
    readonly error?: PhoneActionError;
    /** Adaptive stabilization facts. */
    readonly stability?: Omit<StableScreenResult, 'screenshot'>;
    /** Recent-loop diagnosis. */
    readonly stuck: PhoneStuckStatus;
    /** Observation captured after execution or rejection. */
    readonly observation: PhoneObservation;
}
/** Text and optional image returned by the Phone observation tool. */
export interface PhoneToolObservation {
    /** Canonical JSON observation. */
    readonly observation: PhoneObservation;
    /** Token-optimized hierarchy and device summary. */
    readonly text: string;
    /** Optional visual-provider analysis. */
    readonly vision?: PhoneVisionObservation;
}
/** Result surface returned by the Phone action tool. */
export interface PhoneToolActionResult extends PhoneActionResult {
    /** Token-optimized verification and next-state summary. */
    readonly text: string;
}
/** Optional vision-provider output that never contains an action. */
export interface PhoneVisionObservation {
    /** Concise visual description relevant to the task. */
    readonly summary: string;
    /** Visible labels or controls absent from the hierarchy. */
    readonly visualElements: readonly string[];
}
/** Input to a replaceable visual-analysis provider. */
export interface PhoneVisionRequest {
    /** Exact screenshot bytes. */
    readonly screenshot: Uint8Array;
    /** Current user task. */
    readonly task: string;
    /** Cooperative cancellation. */
    readonly signal: AbortSignal;
}
/** Active Phone run lifecycle state. */
export type PhoneRunStatus = 'starting' | 'running' | 'pausing' | 'paused' | 'stopping' | 'completed' | 'failed' | 'stopped';
/** Observable phase of an action that has not settled yet. */
export type PhoneRunStepPhase = 'observing' | 'executing' | 'awaiting_approval' | 'stabilizing' | 'verifying';
/** User-facing activity derived from the run lifecycle and pending action. */
export type PhoneRunActivity = PhoneRunStepPhase | 'starting' | 'thinking' | 'paused' | 'stopping' | 'finished';
/** One action currently progressing through the Phone runtime. */
export interface PhonePendingStep {
    readonly step: number;
    readonly actionId: PhoneActionId;
    readonly action: PhoneAction;
    readonly phase: PhoneRunStepPhase;
    readonly startedAt: number;
}
/** Bounded state identity retained for developer diagnostics. */
export interface PhoneStepState {
    readonly observationId: PhoneObservationId;
    readonly foregroundPackage?: string;
    readonly activity?: string;
    readonly uiSignature: string;
    readonly screenshotSignature: string;
}
/** Semantic target snapshot captured before an action changes the page. */
export interface PhoneStepTarget {
    readonly elementId?: number;
    readonly accessibilityLabel?: string;
    readonly text?: string;
    readonly role?: string;
    readonly resourceId?: string;
}
/** Optional context enriching a raw action without changing the action protocol. */
export interface PhoneRunStepContext {
    readonly before: PhoneStepState;
    readonly target?: PhoneStepTarget;
}
/** One compact step exposed in the bounded run view and GUI. */
export interface PhoneRunStep {
    /** One-based action step number. */
    readonly step: number;
    /** Action accepted by the runtime. */
    readonly action: PhoneAction;
    /** Verification result. */
    readonly result: PhoneActionResult;
    /** Pre-action semantic and diagnostic context. Absent on legacy snapshots. */
    readonly context?: PhoneRunStepContext;
    /** Compatibility completion timestamp in Unix milliseconds. */
    readonly timestamp: number;
    /** Time at which the runtime accepted the action. */
    readonly startedAt?: number;
    /** Time at which execution and verification settled. */
    readonly completedAt?: number;
}
/** JSON-safe active-run state consumed by Remote and the Web GUI. */
export interface PhoneRunView {
    /** Run identity. */
    readonly id: PhoneRunId;
    /** Owning device. */
    readonly deviceId: PhoneDeviceId;
    /** Original user task. */
    readonly task: string;
    /** Current lifecycle state. */
    readonly status: PhoneRunStatus;
    /** Current user-visible runtime activity. */
    readonly activity?: PhoneRunActivity;
    /** Completed action count. */
    readonly stepCount: number;
    /** Consecutive failed-action count. */
    readonly consecutiveFailures: number;
    /** Run creation time. */
    readonly startedAt: number;
    /** Last state update time. */
    readonly updatedAt: number;
    /** Most recent model-visible observation. */
    readonly observation?: PhoneObservation;
    /** Bounded recent steps. */
    readonly steps: readonly PhoneRunStep[];
    /** First retained step number, or the next step number when the trace is empty. */
    readonly traceStartStep?: number;
    /** Whether older completed steps were removed by the trace bound. */
    readonly traceTruncated?: boolean;
    /** Action currently executing, approving, stabilizing, or verifying. */
    readonly pendingStep?: PhonePendingStep;
    /** Terminal or lifecycle failure message. */
    readonly message?: string;
}
/** Start request after UI or configuration resolves a concrete device. */
export interface StartPhoneRunRequest {
    /** Concrete selected device. */
    readonly deviceId: PhoneDeviceId;
    /** Non-empty natural-language task. */
    readonly task: string;
}
/** Chat-originated start request; the device may be left for the provider to resolve. */
export interface SchedulePhoneRunRequest {
    /** Explicit device, required only when more than one device is online. */
    readonly deviceId?: PhoneDeviceId;
    /** Non-empty natural-language task. */
    readonly task: string;
}
/** A run accepted from chat that starts once the requesting Agent turn ends. */
export interface ScheduledPhoneRun {
    /** Device resolved and validated at scheduling time. */
    readonly deviceId: PhoneDeviceId;
    /** Trimmed task that will start. */
    readonly task: string;
}
/** Minimal tool execution surface shared without importing the concrete tool registry. */
export interface PhoneRunExecution {
    /** Cooperative action cancellation. */
    readonly signal: AbortSignal;
    /** End the current Agent turn after an accepted terminal action. */
    concludeTurn(): void;
}
//# sourceMappingURL=types.d.ts.map