/** Iterative Android Phone run orchestration over the existing Harness Agent loop. */

import { randomUUID } from 'node:crypto'
import { Context } from '@deepseek-ai/cordis'
import type { Fiber } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type { Agent, PreStepDecision } from '@deepseek-ai/dsh-agent'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import {
  PhoneActionId,
  PhoneError,
  PhoneRunId,
  PhoneRunService,
} from '../core/index.ts'
import type {
  PhoneAction,
  PhoneActionError,
  PhoneActionResult,
  PhoneCapture,
  PhoneDevice,
  PhoneDeviceId,
  PhoneDeviceInfo,
  PhoneObservation,
  PhoneRunExecution,
  PhoneRunId as PhoneRunIdType,
  PhonePendingStep,
  PhoneRunStatus,
  PhoneRunStep,
  PhoneRunView,
  PhoneScreenshot,
  PhoneToolActionResult,
  PhoneToolObservation,
  PhoneUIElement,
  PhoneVisionObservation,
  StartPhoneRunRequest,
} from '../core/index.ts'
import * as ToolPhone from '../tools/index.ts'
import type {} from '@deepseek-ai/dsh-user-approval'
import { resolveConfig, type ResolvedConfig } from './config.ts'
import { PhoneActionExecutor } from './executor.ts'
import { revalidateTapElementAction } from './elements.ts'
import { PHONE_AGENT_PROMPT, PHONE_TERMINAL_PROMPT } from './prompt.ts'
import { fitScreenshot } from './screenshot.ts'
import { serializePhoneActionResult, serializePhoneObservation } from './serializer.ts'
import { PhoneStuckDetector } from './stuck-detector.ts'
import { verifyPhoneAction } from './verifier.ts'
import type {} from './events.ts'

export { classifyPhoneAction, requirePhoneApproval } from './approval.ts'
export type { PhoneApprovalRequest } from './approval.ts'
export { resolveConfig } from './config.ts'
export type { ResolvedConfig } from './config.ts'
export { PhoneActionExecutor } from './executor.ts'
export type { ExecutedPhoneAction } from './executor.ts'
export { findStablePhoneElement, revalidateTapElementAction } from './elements.ts'
export type { RejectedTapElementAction, RevalidatedTapElementAction } from './elements.ts'
export { PHONE_AGENT_PROMPT, PHONE_TERMINAL_PROMPT } from './prompt.ts'
export { serializePhoneActionResult, serializePhoneObservation } from './serializer.ts'
export { PhoneStuckDetector } from './stuck-detector.ts'
export type { StuckRecord } from './stuck-detector.ts'
export { verifyPhoneAction } from './verifier.ts'
export type * from './events.ts'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'phone-agent'

/** Deployment tunables for Phone Agent runs. */
export interface Config {
  /** Maximum non-observation actions in one run. */
  maxSteps?: number
  /** Maximum run lifetime in milliseconds. */
  taskTimeoutMs?: number
  /** Maximum one-action execution time. */
  actionTimeoutMs?: number
  /** Consecutive verified failures before termination. */
  maxConsecutiveFailures?: number
  /** Stable-screen poll interval. */
  stablePollMs?: number
  /** Consecutive stable samples. */
  stableSamples?: number
  /** Stable-screen timeout. */
  stableTimeoutMs?: number
  /** Normalized screenshot difference treated as stable. */
  stableDifferenceThreshold?: number
  /** Whether consequential actions require Harness approval. */
  approvalEnabled?: boolean
  /** Whether screenshots enter model-visible attachment storage. */
  traceScreenshots?: boolean
  /** Maximum recent step records retained in the live Remote view. */
  maxTraceSteps?: number
}

/** Public alias naming Phone run configuration. */
export type PhoneAgentConfig = Config

/** Loader-visible Phone run configuration schema. */
export const Config: z<Config> = z.object({
  maxSteps: z.number().default(50),
  taskTimeoutMs: z.number().default(10 * 60_000),
  actionTimeoutMs: z.number().default(10_000),
  maxConsecutiveFailures: z.number().default(5),
  stablePollMs: z.number().default(300),
  stableSamples: z.number().default(3),
  stableTimeoutMs: z.number().default(5_000),
  stableDifferenceThreshold: z.number().default(0.01),
  approvalEnabled: z.boolean().default(true),
  traceScreenshots: z.boolean().default(true),
  maxTraceSteps: z.number().default(100),
})

/** Internal mutable state for one reserved Agent/device run. */
interface PhoneRun {
  readonly id: PhoneRunIdType
  readonly agent: Agent
  readonly device: PhoneDevice
  readonly task: string
  readonly startedAt: number
  readonly abort: AbortController
  readonly stuck: PhoneStuckDetector
  fiber?: Fiber
  status: PhoneRunStatus
  updatedAt: number
  stepCount: number
  consecutiveFailures: number
  steps: PhoneRunStep[]
  pendingStep?: PhonePendingStep
  lastObservation?: PhoneObservation
  message?: string
  queue: Promise<void>
  finalized: boolean
}

/** Runtime-only options passed to the Agent-scoped Phone composition plugin. */
interface PhoneRunScopeOptions {
  readonly owner: PhoneAgentService
  readonly run: PhoneRun
}

/** Runtime-only snapshot passed to the post-run safety scope. */
interface PhoneTerminalScopeOptions {
  readonly run: PhoneRunView
}

/** Concrete active-run Provider layered over the existing Agent, Tool, Session, and approval plugins. */
export class PhoneAgentService extends PhoneRunService {
  /** Required Host services; approval and vision remain optional services. */
  static inject = ['phone', 'agents', 'attachments', 'llm', 'systemPrompt', 'tools']
  /** Loader-visible orchestration configuration. */
  static Config = Config

  private readonly config: ResolvedConfig
  private readonly executor: PhoneActionExecutor
  private readonly runs = new Map<Agent, PhoneRun>()
  private readonly lastViews = new Map<Agent, PhoneRunView>()
  private readonly terminalFibers = new Map<Agent, Fiber>()
  private readonly devices = new Map<PhoneDeviceId, PhoneRun>()
  private readonly knownDevices = new Map<PhoneDeviceId, PhoneDeviceInfo>()
  private disposing = false

  /**
   * Register the concrete `ctx.phoneRuns` provider.
   * @param ctx - Host context carrying Agent, Phone, attachment, LLM, prompt, and tool services.
   * @param config - Run limits, stability, approval, and trace policy.
   */
  constructor(ctx: Context, config: Config = {}) {
    super(ctx)
    this.config = resolveConfig(config)
    this.executor = new PhoneActionExecutor(ctx, this.config)
    ctx.on('agent/status', ({ agent, status }) => {
      if (status !== 'idle') return
      const run = this.runs.get(agent)
      if (run?.status === 'running') this.stopAbandonedRun(run)
    })
    ctx.on('agent/disposed', ({ agent }) => {
      this.lastViews.delete(agent)
      const terminalFiber = this.terminalFibers.get(agent)
      this.terminalFibers.delete(agent)
      if (terminalFiber !== undefined) void terminalFiber.dispose().catch((error: unknown) => {
        ctx.logger.warn('phone-agent: terminal guard disposal failed: %o', error)
      })
      const run = this.runs.get(agent)
      if (run !== undefined) void this.stopInternal(run, 'disposed', 'Agent disposed').catch((error: unknown) => {
        ctx.logger.warn('phone-agent: Agent disposal cleanup failed: %o', error)
      })
    })
    ctx.effect(() => async () => {
      this.disposing = true
      const outcomes = await Promise.allSettled([
        ...[...this.runs.values()].map(run => this.stopInternal(run, 'disposed', 'Phone Agent plugin disposed')),
        ...[...this.terminalFibers.values()].map(fiber => fiber.dispose()),
      ])
      this.terminalFibers.clear()
      const failures = outcomes.flatMap(outcome => outcome.status === 'rejected' ? [outcome.reason as unknown] : [])
      if (failures.length === 1) throw failures[0]
      if (failures.length > 1) throw new AggregateError(failures, 'Phone Agent teardown failed')
    }, 'phone-agent teardown')
  }

  /**
   * List current provider devices for Remote and GUI selection.
   * @param signal - Cooperative cancellation.
   * @returns Current device records.
   */
  async listDevices(signal?: AbortSignal): Promise<readonly PhoneDeviceInfo[]> {
    const devices = await this.ctx.phone.list(signal)
    this.publishDeviceSnapshot(devices)
    return devices
  }

  /**
   * Connect one wireless ADB address through the selected provider.
   * @param address - Valid provider endpoint.
   * @param signal - Cooperative cancellation.
   * @returns Connected record.
   */
  async connect(address: string, signal?: AbortSignal): Promise<PhoneDeviceInfo> {
    const device = await this.ctx.phone.connect(address, signal)
    this.publishDeviceState(device)
    return device
  }

  /**
   * Start one Phone run on an idle Agent and unreserved device.
   * @param agent - Existing live Agent whose loop drives decisions.
   * @param request - Concrete device and natural-language task.
   * @param signal - Cooperative startup cancellation.
   * @returns Initial published run view.
   */
  async start(agent: Agent, request: StartPhoneRunRequest, signal?: AbortSignal): Promise<PhoneRunView> {
    if (agent.status !== 'idle') throw new PhoneError('PHONE_RUN_NOT_ACTIVE', 'Phone run start requires an idle Agent')
    if (this.runs.has(agent)) throw new PhoneError('PHONE_DEVICE_BUSY', 'Agent already owns a Phone run')
    if (this.devices.has(request.deviceId)) throw new PhoneError('PHONE_DEVICE_BUSY', `device ${request.deviceId} is already reserved`)
    const task = request.task.trim()
    if (task.length === 0) throw new PhoneError('PHONE_ACTION_REJECTED', 'Phone task must be non-empty')
    await this.clearTerminalScope(agent)
    const device = await this.ctx.phone.open(request.deviceId, signal)
    this.lastViews.delete(agent)
    const startedAt = Date.now()
    const run: PhoneRun = {
      id: PhoneRunId(randomUUID()),
      agent,
      device,
      task,
      startedAt,
      updatedAt: startedAt,
      abort: new AbortController(),
      stuck: new PhoneStuckDetector(),
      status: 'starting',
      stepCount: 0,
      consecutiveFailures: 0,
      steps: [],
      queue: Promise.resolve(),
      finalized: false,
    }
    this.runs.set(agent, run)
    this.devices.set(device.id, run)
    try {
      run.fiber = await agent.ctx.plugin(PhoneRunScopePlugin, { owner: this, run })
      const operationSignal = startupSignal(signal, run.abort.signal)
      const capture = await device.getState(operationSignal)
      const observation = await this.prepareObservation(run, capture, operationSignal)
      run.lastObservation = observation.observation
      run.status = 'running'
      run.updatedAt = Date.now()
      const view = this.view(run)
      this.ctx.emit('phone/agent/started', { agent, run: view })
      this.ctx.emit('phone/observation', { agent, run: view, observation: observation.observation })
      agent.followup(createUserMessage({
        source: { kind: 'plugin', plugin: 'phone-agent' },
        content: modelContent(`Phone task started.\n${observation.text}`, observation.observation),
      }))
      return view
    } catch (error: unknown) {
      await this.finalize(run, false)
      throw error
    }
  }

  /** @inheritdoc */
  async observe(agent: Agent, signal: AbortSignal): Promise<PhoneToolObservation> {
    const run = this.requireRun(agent)
    this.assertRunning(run)
    const operationSignal = this.runSignal(run, signal)
    const capture = await run.device.getState(operationSignal)
    const observation = await this.prepareObservation(run, capture, operationSignal)
    run.lastObservation = observation.observation
    run.updatedAt = Date.now()
    const view = this.view(run)
    this.ctx.emit('phone/observation', { agent, run: view, observation: observation.observation })
    return observation
  }

  /** @inheritdoc */
  act(agent: Agent, action: PhoneAction, execution: PhoneRunExecution): Promise<PhoneToolActionResult> {
    const run = this.requireRun(agent)
    return this.enqueue(run, () => this.actSerial(run, action, execution))
  }

  /**
   * Return one Agent's bounded current run view.
   * @param agent - Exact run owner.
   * @returns View or undefined before a run starts.
   */
  getView(agent: Agent): PhoneRunView | undefined {
    const run = this.runs.get(agent)
    return run === undefined ? this.lastViews.get(agent) : this.view(run)
  }

  /**
   * Capture a fresh GUI screenshot for one Agent's reserved device.
   * @param agent - Exact run owner.
   * @param signal - Cooperative cancellation.
   * @returns Fresh bounded screenshot.
   */
  async getScreenshot(agent: Agent, deviceId?: PhoneDeviceId, signal?: AbortSignal): Promise<PhoneScreenshot> {
    const run = this.runs.get(agent)
    if (run !== undefined) {
      if (deviceId !== undefined && deviceId !== run.device.id) {
        throw new PhoneError('PHONE_DEVICE_BUSY', `Agent run owns ${run.device.id}, not ${deviceId}`)
      }
      return run.device.screenshot(signal)
    }
    if (deviceId === undefined) throw new PhoneError('PHONE_RUN_NOT_FOUND', 'select a device before requesting a screenshot')
    const owner = this.devices.get(deviceId)
    if (owner !== undefined && owner.agent !== agent) {
      throw new PhoneError('PHONE_DEVICE_BUSY', `device ${deviceId} is reserved by another Agent`)
    }
    const device = await this.ctx.phone.open(deviceId, signal)
    return device.screenshot(signal)
  }

  /**
   * Pause after the in-flight action verifies and the current Agent activity reaches idle.
   * @param agent - Exact run owner.
   * @returns Paused run view.
   */
  async pause(agent: Agent): Promise<PhoneRunView> {
    const run = this.requireRun(agent)
    if (run.status !== 'running') throw new PhoneError('PHONE_RUN_NOT_ACTIVE', `cannot pause run in ${run.status}`)
    run.status = 'pausing'
    run.updatedAt = Date.now()
    await run.queue
    await agent.whenIdle()
    if (run.status === 'pausing') {
      run.status = 'paused'
      run.updatedAt = Date.now()
    }
    return this.view(run)
  }

  /**
   * Resume the same run with a fresh observation and plugin follow-up.
   * @param agent - Exact paused run owner.
   * @returns Running view.
   */
  async resume(agent: Agent): Promise<PhoneRunView> {
    const run = this.requireRun(agent)
    if (run.status !== 'paused') throw new PhoneError('PHONE_RUN_NOT_ACTIVE', `cannot resume run in ${run.status}`)
    const capture = await run.device.getState(run.abort.signal)
    const observation = await this.prepareObservation(run, capture, run.abort.signal)
    run.lastObservation = observation.observation
    run.status = 'running'
    run.updatedAt = Date.now()
    agent.followup(createUserMessage({
      source: { kind: 'plugin', plugin: 'phone-agent' },
      content: modelContent(`Resume Phone task: ${run.task}\n${observation.text}`, observation.observation),
    }))
    return this.view(run)
  }

  /**
   * Stop a run requested by the user and await Agent/device quiescence.
   * @param agent - Exact run owner.
   * @returns Terminal stopped view.
   */
  stop(agent: Agent): Promise<PhoneRunView> {
    return this.stopInternal(this.requireRun(agent), 'user', 'Stopped by user')
  }

  /** Release a run whose owning Agent turn ended without a terminal Phone action. */
  private stopAbandonedRun(run: PhoneRun): void {
    if (run.finalized || run.status !== 'running') return
    const message = 'Agent turn ended before the Phone task called finish'
    run.abort.abort(new Error(message))
    run.status = 'stopped'
    delete run.pendingStep
    run.message = message
    run.updatedAt = Date.now()
    this.appendTerminal(run, false)
    const view = this.view(run)
    this.ctx.emit('phone/agent/stopped', { agent: run.agent, run: view })
    void this.finalize(run).catch((error: unknown) => {
      this.ctx.logger.warn('phone-agent: abandoned run cleanup failed: %o', error)
    })
  }

  private async actSerial(
    run: PhoneRun,
    action: PhoneAction,
    execution: PhoneRunExecution,
  ): Promise<PhoneToolActionResult> {
    this.assertRunning(run)
    if (Date.now() - run.startedAt >= this.config.taskTimeoutMs) {
      return this.limitResult(run, action, execution, 'Phone task timeout reached')
    }
    if (run.stepCount >= this.config.maxSteps) {
      return this.limitResult(run, action, execution, `Phone action limit ${this.config.maxSteps} reached`)
    }
    const startedAt = Date.now()
    const actionId = PhoneActionId(randomUUID())
    run.pendingStep = { step: run.stepCount + 1, actionId, action, phase: 'observing', startedAt }
    run.updatedAt = Date.now()
    const signal = this.runSignal(run, execution.signal)
    let before: PhoneCapture
    try {
      before = await run.device.getState(signal)
    } catch (error: unknown) {
      delete run.pendingStep
      run.updatedAt = Date.now()
      throw error
    }
    this.updatePendingPhase(run, 'executing')
    const viewBefore = this.view(run)
    this.ctx.emit('phone/action/started', { agent: run.agent, run: viewBefore, actionId, action })
    if (action.type === 'finish') return this.finish(run, actionId, action, before, execution, startedAt)

    let executableAction: Exclude<PhoneAction, { readonly type: 'finish' }> = action
    if (action.type === 'tap_element') {
      const revalidated = revalidateTapElementAction(action, run.lastObservation, before.observation)
      if ('error' in revalidated) {
        return this.rejectedAction(
          run,
          actionId,
          action,
          before,
          revalidated.error,
          startedAt,
        )
      }
      executableAction = revalidated.action
    }

    const executed = await this.executor.execute(run.agent, run.device, before, executableAction, signal, (request) => {
      this.ctx.emit('phone/approval/required', {
        agent: run.agent,
        run: this.view(run),
        action,
        reason: request.reason,
        impact: request.impact,
      })
    }, phase => { this.updatePendingPhase(run, phase) })
    this.updatePendingPhase(run, 'verifying')
    const prepared = await this.prepareObservation(run, executed.after, signal)
    const stuck = run.stuck.record({
      action,
      before: stateSignature(before.observation),
      after: stateSignature(prepared.observation),
      success: executed.verification.success,
      ...(executed.error === undefined ? {} : { errorCode: executed.error.code }),
    })
    const result: PhoneActionResult = {
      actionId,
      action,
      executed: executed.executed,
      verification: executed.verification,
      ...(executed.error === undefined ? {} : { error: executed.error }),
      ...(executed.stability === undefined ? {} : { stability: executed.stability }),
      stuck,
      observation: prepared.observation,
    }
    this.settleStep(run, result, startedAt, before.observation)
    const text = serializePhoneActionResult(result, prepared.text)
    if (run.consecutiveFailures >= this.config.maxConsecutiveFailures) {
      run.status = 'failed'
      run.message = `Phone run stopped after ${run.consecutiveFailures} consecutive failures`
      run.updatedAt = Date.now()
      execution.concludeTurn()
      this.appendTerminal(run, false)
      this.finalizeWhenIdle(run)
    }
    return { ...result, text }
  }

  private async finish(
    run: PhoneRun,
    actionId: ReturnType<typeof PhoneActionId>,
    action: Extract<PhoneAction, { readonly type: 'finish' }>,
    before: PhoneCapture,
    execution: PhoneRunExecution,
    startedAt: number,
  ): Promise<PhoneToolActionResult> {
    this.updatePendingPhase(run, 'verifying')
    const prepared = await this.prepareObservation(run, before, this.runSignal(run, execution.signal))
    const verification = verifyPhoneAction(before.observation, action, prepared.observation)
    const result: PhoneActionResult = {
      actionId,
      action,
      executed: false,
      verification,
      stuck: { stuck: false },
      observation: prepared.observation,
    }
    this.settleStep(run, result, startedAt, before.observation)
    run.status = action.success ? 'completed' : 'failed'
    run.message = action.message
    run.updatedAt = Date.now()
    execution.concludeTurn()
    this.appendTerminal(run, action.success)
    this.finalizeWhenIdle(run)
    return { ...result, text: serializePhoneActionResult(result, prepared.text) }
  }

  private async rejectedAction(
    run: PhoneRun,
    actionId: ReturnType<typeof PhoneActionId>,
    action: PhoneAction,
    capture: PhoneCapture,
    error: PhoneActionError,
    startedAt: number,
  ): Promise<PhoneToolActionResult> {
    this.updatePendingPhase(run, 'verifying')
    const prepared = await this.prepareObservation(run, capture, run.abort.signal)
    const stuck = run.stuck.record({
      action,
      before: stateSignature(capture.observation),
      after: stateSignature(prepared.observation),
      success: false,
      errorCode: error.code,
    })
    const result: PhoneActionResult = {
      actionId,
      action,
      executed: false,
      verification: { success: false, changed: false, evidence: [error.message] },
      error,
      stuck,
      observation: prepared.observation,
    }
    this.settleStep(run, result, startedAt, capture.observation)
    return { ...result, text: serializePhoneActionResult(result, prepared.text) }
  }

  private async limitResult(
    run: PhoneRun,
    action: PhoneAction,
    execution: PhoneRunExecution,
    message: string,
  ): Promise<PhoneToolActionResult> {
    const startedAt = Date.now()
    const capture = await run.device.getState(this.runSignal(run, execution.signal))
    const result = await this.rejectedAction(
      run,
      PhoneActionId(randomUUID()),
      action,
      capture,
      { code: 'PHONE_RUN_LIMIT_REACHED', message },
      startedAt,
    )
    run.status = 'failed'
    run.message = message
    run.updatedAt = Date.now()
    execution.concludeTurn()
    this.appendTerminal(run, false)
    this.finalizeWhenIdle(run)
    return result
  }

  private settleStep(
    run: PhoneRun,
    result: PhoneActionResult,
    startedAt: number,
    before: PhoneObservation,
  ): void {
    run.stepCount++
    run.consecutiveFailures = result.verification.success ? 0 : run.consecutiveFailures + 1
    run.lastObservation = result.observation
    const completedAt = Date.now()
    run.updatedAt = completedAt
    delete run.pendingStep
    const step: PhoneRunStep = {
      step: run.stepCount,
      action: result.action,
      result,
      context: stepContext(result.action, before),
      timestamp: completedAt,
      startedAt,
      completedAt,
    }
    run.steps.push(step)
    if (run.steps.length > this.config.maxTraceSteps) run.steps.splice(0, run.steps.length - this.config.maxTraceSteps)
    const view = this.view(run)
    const type = result.verification.success ? 'phone/action/completed' : 'phone/action/failed'
    this.ctx.emit(type, { agent: run.agent, run: view, step })
  }

  private async prepareObservation(
    run: PhoneRun,
    capture: PhoneCapture,
    signal: AbortSignal,
  ): Promise<PhoneToolObservation> {
    const imageCapable = this.config.traceScreenshots && await this.imageCapable(run.agent, signal)
    let observation = capture.observation
    if (imageCapable) {
      // Older Harness attachment stores do not publish the per-side limit; 2000px is the stores' default.
      const limits = this.ctx.attachments.imageLimits as object as { readonly maxImageDimension?: number }
      const fitted = await fitScreenshot(capture.screenshot, limits.maxImageDimension ?? 2_000)
      const screenshot = await this.ctx.attachments.saveImage({
        data: fitted.data,
        mediaType: 'image/png',
        name: `phone-${run.device.id}.png`,
      })
      observation = { ...observation, screenshot, ...(fitted.scale === 1 ? {} : { screenshotScale: fitted.scale }) }
    }
    let vision: PhoneVisionObservation | undefined
    if (!imageCapable) {
      const provider = this.ctx.get('phoneVision')
      if (provider !== undefined) {
        try {
          vision = await provider.analyze({ screenshot: capture.screenshot.data, task: run.task, signal })
        } catch (error: unknown) {
          vision = { summary: `Visual analysis unavailable: ${error instanceof Error ? error.message : String(error)}`, visualElements: [] }
        }
      }
    }
    const text = serializePhoneObservation(run.task, observation, vision)
    return { observation, text, ...(vision === undefined ? {} : { vision }) }
  }

  private async imageCapable(agent: Agent, signal: AbortSignal): Promise<boolean> {
    const routed = agent.session.requestHeader()?.config
    const provider = routed?.provider ?? agent.options.provider
    const model = routed?.model ?? agent.options.model
    if (provider === undefined || model === undefined) return false
    try {
      const info = await this.ctx.llm.resolveModelInfo(provider, model, signal)
      return info.inputModalities?.includes('image') === true
    } catch (_modelMetadataUnavailable) {
      return false
    }
  }

  private appendTerminal(run: PhoneRun, success: boolean): void {
    const view = this.view(run)
    if (success) {
      this.ctx.emit('phone/task/completed', { agent: run.agent, run: view })
    } else {
      this.ctx.emit('phone/task/failed', { agent: run.agent, run: view })
    }
  }

  private async stopInternal(
    run: PhoneRun,
    cause: 'user' | 'disposed',
    message: string,
  ): Promise<PhoneRunView> {
    if (run.finalized) return this.view(run)
    run.status = 'stopping'
    delete run.pendingStep
    run.message = message
    run.updatedAt = Date.now()
    run.agent.cancel({ kind: cause })
    run.abort.abort(new Error(message))
    await Promise.allSettled([run.queue, run.agent.whenIdle()])
    try {
      const finalSignal = AbortSignal.timeout(this.config.actionTimeoutMs)
      const capture = await run.device.getState(finalSignal)
      const prepared = await this.prepareObservation(run, capture, finalSignal)
      run.lastObservation = prepared.observation
    } catch (_boundedFinalObservationUnavailable) {
      // Stop remains authoritative even when a disconnected device cannot provide a final observation.
    }
    run.status = 'stopped'
    run.updatedAt = Date.now()
    this.appendTerminal(run, false)
    const view = this.view(run)
    this.ctx.emit('phone/agent/stopped', { agent: run.agent, run: view })
    await this.finalize(run, cause !== 'disposed')
    return view
  }

  private finalizeWhenIdle(run: PhoneRun): void {
    void run.agent.whenIdle().then(() => this.finalize(run)).catch((error: unknown) => {
      this.ctx.logger.warn('phone-agent: terminal cleanup failed: %o', error)
    })
  }

  private async finalize(run: PhoneRun, installTerminalGuard = true): Promise<void> {
    if (run.finalized) return
    run.finalized = true
    const terminalView = this.view(run)
    this.lastViews.set(run.agent, terminalView)
    this.runs.delete(run.agent)
    this.devices.delete(run.device.id)
    await run.fiber?.dispose()
    if (!installTerminalGuard || this.disposing) return
    await this.clearTerminalScope(run.agent)
    const terminalFiber = await run.agent.ctx.plugin(PhoneTerminalScopePlugin, { run: terminalView })
    this.terminalFibers.set(run.agent, terminalFiber)
  }

  /** Remove the safe post-run facade before mounting another active Phone scope. */
  private async clearTerminalScope(agent: Agent): Promise<void> {
    const terminalFiber = this.terminalFibers.get(agent)
    if (terminalFiber === undefined) return
    this.terminalFibers.delete(agent)
    await terminalFiber.dispose()
  }

  private publishDeviceSnapshot(devices: readonly PhoneDeviceInfo[]): void {
    const seen = new Set<PhoneDeviceId>()
    for (const device of devices) {
      seen.add(device.id)
      this.publishDeviceState(device)
    }
    for (const previous of this.knownDevices.values()) {
      if (seen.has(previous.id) || previous.status !== 'device') continue
      const disconnected: PhoneDeviceInfo = { ...previous, status: 'offline' }
      this.knownDevices.set(previous.id, disconnected)
      this.ctx.emit('phone/disconnected', disconnected)
    }
  }

  private publishDeviceState(device: PhoneDeviceInfo): void {
    const previous = this.knownDevices.get(device.id)
    this.knownDevices.set(device.id, device)
    if (device.status === 'device' && previous?.status !== 'device') {
      this.ctx.emit('phone/connected', device)
    } else if (device.status !== 'device' && previous?.status === 'device') {
      this.ctx.emit('phone/disconnected', device)
    }
  }

  private requireRun(agent: Agent): PhoneRun {
    const run = this.runs.get(agent)
    if (run === undefined) throw new PhoneError('PHONE_RUN_NOT_FOUND', 'Agent does not own a Phone run')
    return run
  }

  private assertRunning(run: PhoneRun): void {
    if (run.status !== 'running') throw new PhoneError('PHONE_RUN_NOT_ACTIVE', `Phone run is ${run.status}`)
  }

  private runSignal(run: PhoneRun, signal: AbortSignal): AbortSignal {
    return AbortSignal.any([run.abort.signal, signal])
  }

  private updatePendingPhase(run: PhoneRun, phase: PhonePendingStep['phase']): void {
    if (run.pendingStep === undefined) return
    run.pendingStep = { ...run.pendingStep, phase }
    run.updatedAt = Date.now()
  }

  private enqueue<T>(run: PhoneRun, operation: () => Promise<T>): Promise<T> {
    const previous = run.queue
    let release: () => void = () => {}
    run.queue = new Promise<void>((resolve) => { release = resolve })
    return previous.then(operation).finally(release)
  }

  private view(run: PhoneRun): PhoneRunView {
    const traceStartStep = run.steps[0]?.step ?? run.stepCount + 1
    return {
      id: run.id,
      deviceId: run.device.id,
      task: run.task,
      status: run.status,
      activity: run.pendingStep?.phase ?? runActivity(run.status),
      stepCount: run.stepCount,
      consecutiveFailures: run.consecutiveFailures,
      startedAt: run.startedAt,
      updatedAt: run.updatedAt,
      ...(run.lastObservation === undefined ? {} : { observation: run.lastObservation }),
      steps: [...run.steps],
      traceStartStep,
      traceTruncated: traceStartStep > 1,
      ...(run.pendingStep === undefined ? {} : { pendingStep: run.pendingStep }),
      ...(run.message === undefined ? {} : { message: run.message }),
    }
  }
}

function runActivity(status: PhoneRunStatus): Exclude<PhoneRunView['activity'], undefined> {
  switch (status) {
    case 'starting': return 'starting'
    case 'running': return 'thinking'
    case 'pausing': return 'thinking'
    case 'paused': return 'paused'
    case 'stopping': return 'stopping'
    case 'completed':
    case 'failed':
    case 'stopped': return 'finished'
  }
}

/** Agent-scoped plugin that contributes Phone-only tools, prompt, restriction, and pause gate. */
async function PhoneRunScopePlugin(ctx: Context, options: PhoneRunScopeOptions): Promise<void> {
  ctx.tools.restrict({ allow: [] })
  ctx.systemPrompt.section({ name: 'phone-agent:rules', order: 120, text: PHONE_AGENT_PROMPT })
  ctx.on('agent/pre-step', async ({ agent }, next): Promise<PreStepDecision> => {
    if (agent !== options.run.agent) return next()
    return options.run.status === 'running' ? next() : { kind: 'reject' }
  })
  await ctx.plugin(ToolPhone)
}

/** Agent-scoped terminal facade that resolves stale calls without touching a device. */
function PhoneTerminalScopePlugin(ctx: Context, options: PhoneTerminalScopeOptions): void {
  ctx.systemPrompt.section({ name: 'phone-agent:terminal', order: 120, text: PHONE_TERMINAL_PROMPT })
  ToolPhone.applyInactive(ctx, {
    status: options.run.status,
    ...(options.run.message === undefined ? {} : { message: options.run.message }),
  })
}

/** Combine optional startup cancellation with run ownership. */
function startupSignal(signal: AbortSignal | undefined, runSignal: AbortSignal): AbortSignal {
  return signal === undefined ? runSignal : AbortSignal.any([signal, runSignal])
}

/** Build model blocks without adding an image to a text-only route. */
function modelContent(text: string, observation: PhoneObservation): ContentBlock[] {
  return [
    { type: 'text', text },
    ...(observation.screenshot === undefined ? [] : [{ type: 'image' as const, attachment: observation.screenshot }]),
  ]
}

/** Combined signature used only for bounded stuck detection. */
function stateSignature(observation: PhoneObservation): string {
  return `${observation.foregroundPackage ?? ''}|${observation.activity ?? ''}|${observation.uiSignature}|${observation.screenshotSignature}`
}

function stepContext(action: PhoneAction, before: PhoneObservation): NonNullable<PhoneRunStep['context']> {
  const target = actionTarget(action, before)
  return {
    before: {
      observationId: before.id,
      ...(before.foregroundPackage === undefined ? {} : { foregroundPackage: before.foregroundPackage }),
      ...(before.activity === undefined ? {} : { activity: before.activity }),
      uiSignature: before.uiSignature,
      screenshotSignature: before.screenshotSignature,
    },
    ...(target === undefined ? {} : { target: {
      ...('id' in target ? { elementId: target.id } : {}),
      ...(target.contentDescription === undefined ? {} : { accessibilityLabel: target.contentDescription }),
      ...(target.text === undefined ? {} : { text: target.text }),
      role: elementRole(target),
      ...(target.resourceId === undefined ? {} : { resourceId: target.resourceId }),
    } }),
  }
}

function actionTarget(action: PhoneAction, observation: PhoneObservation): PhoneUIElement | undefined {
  if (action.type === 'tap_element') return observation.elements.find(element => element.id === action.elementId)
  if (action.type === 'input_text' || action.type === 'replace_text' || action.type === 'press_key') {
    return observation.elements.find(element => element.editable && element.focused)
  }
  if (action.type === 'tap' || action.type === 'long_press') {
    return observation.elements.find((element) => {
      const [left, top, right, bottom] = element.bounds
      return action.x >= left && action.x <= right && action.y >= top && action.y <= bottom
    })
  }
  return undefined
}

function elementRole(element: PhoneUIElement): string {
  if (element.editable) return 'text_field'
  if (element.scrollable) return 'scroll_container'
  if (element.className.endsWith('Button')) return 'button'
  if (element.className.endsWith('Switch')) return 'switch'
  return element.clickable ? 'control' : 'element'
}

export default PhoneAgentService
