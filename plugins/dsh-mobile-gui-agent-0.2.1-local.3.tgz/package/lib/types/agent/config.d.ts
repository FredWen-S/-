/** Phone run orchestration configuration and explicit defaults. */
import type { Config } from './index.ts';
/** Complete validated run configuration. */
export interface ResolvedConfig {
    readonly maxSteps: number;
    readonly taskTimeoutMs: number;
    readonly actionTimeoutMs: number;
    readonly maxConsecutiveFailures: number;
    readonly stablePollMs: number;
    readonly stableSamples: number;
    readonly stableTimeoutMs: number;
    readonly stableDifferenceThreshold: number;
    readonly approvalEnabled: boolean;
    readonly traceScreenshots: boolean;
    readonly maxTraceSteps: number;
}
/**
 * Materialize and validate Phone run defaults.
 * @param config - Loader-parsed configuration.
 * @returns Complete configuration.
 */
export declare function resolveConfig(config: Config): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map