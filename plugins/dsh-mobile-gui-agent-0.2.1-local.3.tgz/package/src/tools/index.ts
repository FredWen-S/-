/** Agent-scoped model-facing Phone observation and single-action tools. */

import type { Context } from '@deepseek-ai/cordis'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import { snapshotJsonValue } from '@deepseek-ai/dsh-session'
import type { JsonValue } from '@deepseek-ai/dsh-session'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { InferValue, ToolRunContext, ValueSchemaSpec } from '@deepseek-ai/dsh-tools'
import { PHONE_ACTION_PARAMETERS, parsePhoneAction } from './schema.ts'

export { PHONE_ACTION_PARAMETERS, PHONE_ACTION_SCHEMA, PHONE_KEYS, parsePhoneAction } from './schema.ts'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'tool-phone'
/** Active-run and tool-registry dependencies. */
export const inject = ['tools', 'phoneRuns']

const screenshotSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    attachmentId: { type: 'string', required: true },
    mediaType: { type: 'string', required: true, enum: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'] },
    bytes: { type: 'integer', required: true },
    width: { type: 'integer', required: true },
    height: { type: 'integer', required: true },
    name: { type: 'string' },
  },
} as const

const TOOL_OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    text: { type: 'string', required: true },
    payload: { type: 'json', required: true },
    screenshot: screenshotSchema,
  },
} as const satisfies ValueSchemaSpec

const toolOutput = {
  schema: TOOL_OUTPUT_SCHEMA,
  render: (_args: unknown, value: InferValue<typeof TOOL_OUTPUT_SCHEMA>): ContentBlock[] => [
    { type: 'text' as const, text: value.text },
    ...(value.screenshot === undefined
      ? []
      : [{ type: 'image' as const, attachment: value.screenshot as ImageAttachmentRef }]),
  ],
} as const

/**
 * Register the two scoped Phone tools on the current context.
 * @param ctx - Agent-scoped context carrying `ctx.phoneRuns` and `ctx.tools`.
 */
export function apply(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: 'phone_observe',
    description: 'Observe the current Android screen and compact interactive UI before choosing one action.',
    parameters: {},
    output: toolOutput,
    async execute(_args, execution) {
      const result = await ctx.phoneRuns.observe(requireAgent(execution), execution.signal)
      return outputValue(result.text, result, result.observation.screenshot)
    },
  }))
  ctx.tools.register(defineTool({
    name: 'phone_act',
    description: 'Execute exactly one Android action, wait for stabilization, verify it, and return the next observation. Pass one direct action object, for example {"action":{"type":"tap","x":100,"y":200}}; do not nest another action key.',
    parameters: PHONE_ACTION_PARAMETERS,
    output: toolOutput,
    async execute(args, execution) {
      const result = await ctx.phoneRuns.act(requireAgent(execution), parsePhoneAction(args.action), execution)
      return outputValue(result.text, result, result.observation.screenshot)
    },
  }))
}

/** Terminal run state exposed by the safe inactive Phone tool facade. */
export interface InactivePhoneToolState {
  readonly status: string
  readonly message?: string
}

/**
 * Register no-op Phone tools after the real run scope has ended.
 *
 * Keeping the public names resolvable prevents a model from hitting Harness's
 * UNKNOWN_TOOL path when conversation history contains earlier Phone calls.
 * These implementations never resolve a device or execute an Android action.
 */
export function applyInactive(ctx: Context, state: InactivePhoneToolState): void {
  ctx.tools.register(defineTool({
    name: 'phone_observe',
    description: 'Inactive Phone safety guard. The previous Phone task has ended; this only reports PHONE_RUN_NOT_ACTIVE and never reads a device.',
    parameters: {},
    output: toolOutput,
    async execute() {
      return inactiveOutput(state)
    },
  }))
  ctx.tools.register(defineTool({
    name: 'phone_act',
    description: 'Inactive Phone safety guard. The previous Phone task has ended; this only reports PHONE_RUN_NOT_ACTIVE and never performs an action.',
    parameters: PHONE_ACTION_PARAMETERS,
    output: toolOutput,
    async execute() {
      return inactiveOutput(state)
    },
  }))
}

/** Require the Agent ownership that gives a Phone run meaning. */
function requireAgent(execution: ToolRunContext): NonNullable<ToolRunContext['agent']> {
  if (execution.agent === undefined) throw new Error('Phone tools require an owning Agent')
  return execution.agent
}

/** Convert a typed result to the lossless JSON output boundary. */
function outputValue(
  text: string,
  result: unknown,
  screenshot: ImageAttachmentRef | undefined,
): InferValue<typeof TOOL_OUTPUT_SCHEMA> {
  const payload = snapshotJsonValue(result) as JsonValue | undefined
  if (payload === undefined) throw new Error('Phone tool result is not lossless JSON')
  return {
    text,
    payload,
    ...(screenshot === undefined ? {} : { screenshot }),
  }
}

/** Build a deterministic, device-free result for a stale Phone tool call. */
function inactiveOutput(state: InactivePhoneToolState): InferValue<typeof TOOL_OUTPUT_SCHEMA> {
  const recovery = 'Start a new Phone task from the Mobile view.'
  const text = `PHONE_RUN_NOT_ACTIVE: The previous Phone task is ${state.status} and has ended. Ordinary chat text cannot approve or resume it. ${recovery}`
  return outputValue(text, {
    active: false,
    error: {
      code: 'PHONE_RUN_NOT_ACTIVE',
      message: text,
    },
    run: {
      status: state.status,
      ...(state.message === undefined ? {} : { message: state.message }),
    },
    recovery,
  }, undefined)
}
